library(dplyr, warn.conflicts = FALSE)
library(dtplyr)
library(tidyr)
library(usethis)

data_DeLaMaza_2021   <- read.csv("data-raw/choice_data.csv",na.strings=c("NA","NS")) %>%
    ## Scaling variables in miles
    dplyr::mutate(dplyr::across(dplyr::starts_with(c("forest","land","cost")), ~ . / 1000)) %>%
    ## Scaling variables in hundreds
    dplyr::mutate(dplyr::across(dplyr::starts_with('disease'), ~ . / 100)) %>%
    ##rename disease variable into morbidity.1
    dplyr::rename(
      morbidity.1 = disease.1,
      morbidity.2 = disease.2,
      morbidity.3 = disease.3) %>%
    ## Scaling income into 100.000s
    dplyr::mutate(income = income / 100000) %>%
    ## Scaling electric bill into 1000s
    dplyr::mutate(elec_bill = elec_bill / 1000) %>%
    ## Creating new variable: have you seen any energy generation?
    dplyr::mutate(
      seen_energy = case_when( seen_hydro==1 | seen_power==1 | seen_renewables==1 ~ 1L,
      TRUE ~ 0L
    )) %>%
    ##Interaction Term
    dplyr::mutate(
      forest_x_location.1 = forest.1 * location.1,
      forest_x_location.2 = forest.2 * location.2,
      forest_x_location.3 = forest.3 * location.3) %>%
  tidyr::drop_na()

usethis::use_data(data_DeLaMaza_2021, overwrite = TRUE)
