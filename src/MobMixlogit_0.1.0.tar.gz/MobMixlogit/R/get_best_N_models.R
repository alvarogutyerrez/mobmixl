#' @importFrom stats setNames
#' @export
get_best_N_models <- function(df,
                           N_best_models= 3,
                           apollo_beta,
                           outliers = 9999){


  ## Filtering abnormal results
  df_filtred <- df[rowSums(df[,(colnames(df) %in% names(apollo_beta))] > -1*outliers &
                             df[,(colnames(df) %in% names(apollo_beta))] < outliers ) == sum(colnames(df) %in% names(apollo_beta))   ,]
  #smallest LL
  df_filtred <-  df_filtred[order(df_filtred$LL,decreasing = TRUE),]

  # recover iteration number
  selected_starting_value <-  df_filtred[1,"Iteration"]
  # Recover best results produced
  final_vals <- df_filtred[1:N_best_models,(colnames(df_filtred) %in% names(apollo_beta))]
  #create object to re-estimate the model but with standard errors.

  bag_of_best_models <- lapply(1:N_best_models,
                               FUN = function(i){
                                 start_point_final_model  =  stats::setNames(
                                   object = as.numeric(final_vals[i,]), # row i
                                   nm     = colnames(final_vals) )

  })


  return(bag_of_best_models)

}


