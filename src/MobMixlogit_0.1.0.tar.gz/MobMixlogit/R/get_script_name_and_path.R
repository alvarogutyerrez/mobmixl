#' @export
get_scriptpath <- function() {
  # location of script can depend on how it was invoked:
  # source() and knit() put it in sys.calls()
  path <- NULL

  if(!is.null(sys.calls())) {
    # get name of script - hope this is consisitent!
    path <- as.character(sys.call(1))[2]
    # make sure we got a file that ends in .R, .Rmd or .Rnw
    if (grepl("..+\\.[R|Rmd|Rnw]", path, perl=TRUE, ignore.case = TRUE) )  {
      return(path)
    } else {
      message("Obtained value for path does not end with .R, .Rmd or .Rnw: ", path)
    }
  } else{
    # Rscript and R -f put it in commandArgs
    args <- commandArgs(trailingOnly = FALSE)
  }
  return(path)
}


get_scriptname <- function(route){
  # parse route
  parsed_route <- strsplit(route, split = "/")
  # get the size of the route to capture the name of the current file
  size_route <- length(parsed_route[[1]])
  # get the name of current file (last object of the parsed route)
  file_name <-  parsed_route[[1]][[size_route]]

  return(file_name)
}
