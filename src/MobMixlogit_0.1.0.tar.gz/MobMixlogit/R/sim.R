#' @importFrom stats rbinom  rnorm runif
#' @importFrom mlogit mlogit
#' @importFrom dfidx dfidx
#' @importFrom partykit mob mob_control nodeids
#' @export
sim <- function(scenario = c("stump"),
                n.indiv   = 20,
                n.choices = 2 ,
                n.alter   = 3,
                nrep = 2,
                seed = 0,
                formula = y~x1+x2|z1+z2+z3+z4+z5,
                xi = 0.5,
                delta = 1,
                draws = 20)
{

  if((scenario %in% c("stump", "tree")) ==FALSE ) stop("scenario must be either 'stump' or 'tree'.")

  res <- vector("list", nrep)


  for(i in 1:nrep){
    seed <- seed + 1
    #set seed
    set.seed(seed)
    dgp <- if(scenario == "stump") dgp_stump else dgp_tree
    d  <- dgp(N     = n.indiv,
              t     = n.choices ,
              J     = n.alter,
              xi    = xi,
              delta = delta,
              seed  = seed)

    d$choice <- ave(x     = d$altern * d$chosen,
                    group = d$id,
                    FUN = max)

    # # Delete chosen variable
    d$chosen <- NULL
    ## Reshape from long to wide.
    df_wide <- stats::reshape(data = d[c("id","id_ind", "altern",
                                  "x1", "x2",
                                  "z1","z2","z3","z4","z5",
                                  "choice",
                                  "beta1", "beta2", "leaf" )],
                       idvar = c("id","id_ind"),
                       timevar = "altern",
                       v.names = c("x1", "x2"),
                       direction = "wide",
                       sep = "_")


    #### partykit + mlogit combo ####
    my_fit_for_mlogit <- function(y,
                                  x = NULL,
                                  start = NULL,
                                  weights = NULL,
                                  offset = NULL, ...) {

      #cbind() x and y
      yx <- cbind(y,x)
      #First declare dfidx data
      d <- dfidx::dfidx(data = yx,
                 shape = "wide",
                 choice = "choice",
                 varying = 2:7, ## first if "y", then "x's" and finally "identifiers".
                 sep = "_",
                 idx = list(c("id", "id_ind")),  #obs= choice situation; id = individual
                 idnames = c(NA, "altern"))

      # fit mlogit using d
      clogit_dfidx <- mlogit::mlogit(formula = choice ~ x1 + x2 |0 ,  ##+0 to drop intercepts
                             data    = d,
                             rpar    = c(x1 = 'n',x2 = 'n'),
                             R = draws,
                             panel = TRUE,
                             method = 'bhhh')

      return(clogit_dfidx)
    }

    start_time <- Sys.time()
    model_result <- partykit::mob(choice ~  x1_1 + x1_2 + x1_3 +
                          x2_1 + x2_2 + x2_3 + id + id_ind + 0  | z1 +z2 + z3 + z4 + z5 ,
                        data = df_wide,
                        fit = my_fit_for_mlogit,
                        cluster = id_ind,
                        control = partykit::mob_control(ytype = "data.frame",
                                              xtype = "data.frame",
                                              minsize = 100,
                                              alpha = 0.05,
                                              ordinal = "l2",
                                              nrep = 100000))
    end_time <- Sys.time()
    time_iter <- round(end_time - start_time, digits = 4)


    ## probability of correctly select z1
    if (scenario == "stump") {
      #split point
      root_test   <- model_result$node$info$test
      z1_correct  <- as.numeric(1L * (min(root_test[2,])==root_test[2,1]))

    }

    # predicted node
    prednode   <- stats::predict(model_result, type = "node")




    # predicted Individual Level Parameters
    ILP_param <- partykit::nodeapply(obj = model_result,
                           ids = partykit::nodeids(model_result,terminal = TRUE),
                           FUN = function(x) fitted(object = x$info$object,
                                                    type = "parameters"))
    ## turn list into data.frame
    ILP_param <- do.call(rbind.data.frame, ILP_param)
    ## Rename columns
    colnames(ILP_param) <- c("id_ind","beta1_hat", "beta2_hat")
    # Attach them to the entire data.frame() df_wide
    df_wide  <- merge(x = df_wide,
                      y = ILP_param,
                      by = "id_ind", #note that it needs to be done at the level of individuals!
                      all = TRUE)




    err_beta_1 <-  mean(sqrt((df_wide$beta1_hat - df_wide$beta1)^2))
    err_beta_2 <-  mean(sqrt((df_wide$beta2_hat - df_wide$beta2)^2))

    ## Relative Error of each parameter
    rel_err_beta_1 <- mean(abs((df_wide$beta1_hat - df_wide$beta1) / df_wide$beta1  ))
    rel_err_beta_2 <- mean(abs((df_wide$beta2_hat - df_wide$beta2) / df_wide$beta2  ))

    ## Adjust Rand Index
    ari <- as.numeric(adj_rand_index(prednode, df_wide$leaf ))

    #LL MNL-MOB
    LL <- as.numeric(stats::logLik(model_result))
    ## LL no partition
    LL_no_part <- (-1L)*as.numeric(model_result$node$info$objfun)
    # n param
    nParam          <- length(stats::coef(model_result))
    nParam_no_part  <- length(stats::coef(model_result$node$info$object))

    ## Construction of the rho2 mcfadden
    ## Log-Likelihood Null
    LL_0 <- attr(model_result$node$info$object$logLik, "null")

    ## Rho2 McFadden
    rho_part    <-  1 - LL/LL_0
    rho_no_part <-  1 - LL_no_part/LL_0 #same as mlogit:::mfR2(model_result$node$info$object)

    ## Adjusted Rho2 McFadden [Ben-AkivaandLerman(1985)]
    rho_adj_part    <- 1 - (LL - nParam )/LL_0
    rho_adj_no_part <- 1 - (LL_no_part - nParam_no_part )/LL_0

    #n choice sets
    n_choice_sets <- length(df_wide$id)

    #Information Criteria
    bic  <- -2 * LL + nParam * log(n_choice_sets)
    aic  <- -2 * LL + 2 * nParam
    caic <- -2 * LL + nParam * (1 + log(n_choice_sets))



    ## Store list
    if (scenario == "stump"){
      ari <- NaN
    } else{
      z1_correct <- NaN
    }

    returnlist <- list(scenario   = scenario  ,
                       time_iter  = time_iter ,
                       seed       = seed      ,
                       n.indiv    = n.indiv   ,
                       n.choices  = n.choices ,
                       n.alter    = n.alter   ,
                       xi         = xi        ,
                       draws      = draws,
                       delta      = delta     ,
                       err_beta_1 = err_beta_1,
                       err_beta_2 = err_beta_2,
                       rel_err_beta_1 = rel_err_beta_1,
                       rel_err_beta_2 = rel_err_beta_2,
                       z1_correct = z1_correct,
                       ari        = ari       ,
                       LL              = LL             ,
                       LL_no_part      = LL_no_part     ,
                       LL_0            = LL_0           ,
                       rho_part        = rho_part       ,
                       rho_no_part     = rho_no_part    ,
                       rho_adj_part    = rho_adj_part   ,
                       rho_adj_no_part = rho_adj_no_part,
                       nParam          = nParam         ,
                       nParam_no_part  = nParam_no_part ,
                       bic             = bic            ,
                       aic             = aic            ,
                       caic            = caic           )

    # just to show that something is happening
    print(paste0("seed = ",seed,
                 " n.indiv = ",n.indiv,
                 " n.choices = ",n.choices,
                 " xi = ",xi,
                 " delta = ",delta,
                 " time_iter = ",time_iter,
                 " scenario = ", scenario ))

    res[[i]]  <- returnlist


  }
  return(res)
}
