#' @importFrom apollo apollo_lcUnconditionals apollo_validateInputs
#' @importFrom utils capture.output
#' @importFrom maxLik maxValue
#' @export

gen_info_model <- function(model,
                           apollo_inputs,
                           apollo_probabilities){

  ## Save Unconditional Probabilities
  log <- utils::capture.output({
    apollo_inputs = apollo::apollo_validateInputs()
  })

  # Unconditional probabilities.
  log <- utils::capture.output({
    uncond = apollo::apollo_lcUnconditionals(
      model = model ,
      apollo_inputs        = apollo_inputs,
      apollo_probabilities = apollo_probabilities)
  })


  mean_proba_class <- lapply(seq_along(names(uncond$pi_values)), function(x){
    # Get to the section of the list that stores the unconditional probabilities
    temp <- uncond$pi_values
    # Select the mean of each class
    mean_proba_class  <- mean(`[[`(temp, names(uncond$pi_values)[x]))
    # named the list using the names from the original Apollo object
    names(mean_proba_class) <- names(uncond$pi_values)[x]
    # Return the object
    return(mean_proba_class)
  })

  #Unlist into a Named num object.
  mean_proba_class<- unlist(mean_proba_class)

  ## Maximum Log-likelihood
  LL_max <-   maxLik::maxValue(model); names(LL_max) <- "LL"

  ## Time Taken
  time_taken <- model$timeTaken; names(time_taken) <- "time_taken"

  ## Number of iterations
  N_iterations <- model$nIter ; names(N_iterations) <- "N_iterations"



  res <- c(LL_max,
           mean_proba_class,
           time_taken,
           N_iterations,
           coef(model))

  # Return
  return(res)

}

