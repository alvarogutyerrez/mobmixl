#' @importFrom apollo apollo_validateInputs apollo_attach apollo_detach apollo_mnl apollo_panelProd apollo_prepareProb apollo_estimate
#' @importFrom utils capture.output
#' @importFrom stats setNames
#' @export

MNL_empirical <- function(data_wide){

  # Remove overload of apollo_objects in the .GlobalEnv
  clear_apollo_overflow()

  # database object in .GlovEnv (unfortunately apollo requires that...)
  assign_for_apollo(
    name_apollo_object = "database",
    value_object = data_wide
    )

  # Set core controls
  assign_for_apollo(
    name_apollo_object  = "apollo_control",
    value_object = list(
      modelName       = "MNL_empirical_application",
      mixing          = FALSE,
      indivID         = "id",
      nCores          = 1,
      outputDirectory = NULL
    )
  )

  # Apollo beta
  assign_for_apollo(
    name_apollo_object  = "apollo_beta",
    value_object = c(asc1        =  0,
                     asc2        =  0.01,
                     asc3        =  0,
                     forest      =  -0.5,
                     morbidity   = -1,
                     land        = -0.01,
                     cost        = -3,
                     location    = 0.1 )
  )

  # Fixed parameters (none)
  assign_for_apollo(
    name_apollo_object  = "apollo_fixed",
    value_object = c( "asc3" )
  )




  # ################################################################# #
  #### GROUP AND VALIDATE INPUTS                                   ####
  # ################################################################# #
  log <- utils::capture.output({

    apollo_inputs = apollo::apollo_validateInputs()

  })

  assign_for_apollo(
    name_apollo_object = "apollo_probabilities",
    value_object = function(apollo_beta,
                            apollo_inputs,
                            functionality="estimate"){

      ### Attach inputs and detach after function exit
      apollo_attach(apollo_beta, apollo_inputs)
      on.exit(apollo_detach(apollo_beta, apollo_inputs))

      ### Create list of probabilities P
      P = list()

      ### List of utilities: these must use the same names as in mnl_settings, order is irrelevant
      V = list()
      V[["alt1"]]  = asc1 + forest*forest.1 + morbidity*morbidity.1 + land*land.1 + cost*cost.1 + location* location.1
      V[["alt2"]]  = asc2 + forest*forest.2 + morbidity*morbidity.2 + land*land.2 + cost*cost.2 + location* location.2
      V[["alt3"]]  = asc3 + forest*forest.3 + morbidity*morbidity.3 + land*land.3 + cost*cost.3 + location* location.3

      ### Define settings for MNL model component
      mnl_settings = list(
        alternatives = c(   alt1=1, alt2=2, alt3=3),
        avail        = list(alt1=1, alt2=1, alt3=1),
        choiceVar    = choice,
        utilities     = V
      )


      ### Compute probabilities using MNL model
      P[["model"]] = apollo_mnl(mnl_settings, functionality)

      ### Take product across observation for same individual
      P = apollo_panelProd(P, apollo_inputs, functionality)

      ### Prepare and return outputs of function
      P = apollo_prepareProb(P, apollo_inputs, functionality)
      return(P)
    }
  )



  log <- utils::capture.output({

    MNL_model <-  apollo::apollo_estimate(
      apollo_beta,
      apollo_fixed,
      apollo_probabilities,
      apollo_inputs,
      estimate_settings = list(hessianRoutine = "numDeriv",
                               writeIter = FALSE))
  })



  # Remove overload of apollo_objects in the .GlobalEnv
  clear_apollo_overflow()
  cat("\n","MNL correctly estimated on De La Maza's Data","\n")

  # return MNL estimates.
  return(MNL_model$estimate)

}
