#' @export
adj_rand_index <- function(x, y) {
  # function to compute adjusted Rand Index
  tab <- table(x, y)
  a <- rowSums(tab)
  b <- colSums(tab)

  M <- sum(choose(tab, 2))
  N <- choose(length(x), 2)
  A <- sum(choose(a, 2))
  B <- sum(choose(b, 2))

  c(ARI = (M - (A * B) / N) / (0.5 * (A + B) - (A * B) / N))
}
