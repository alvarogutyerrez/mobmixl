#' @importFrom apollo apollo_validateInputs apollo_attach apollo_detach apollo_mnl apollo_panelProd apollo_prepareProb apollo_estimate
#' @importFrom utils capture.output
#' @export
MNL_sim <- function(data_wide){


  # Remove overload of apollo_objects in the .GlobalEnv
  clear_apollo_overflow()



  # database object in .GlovEnv (unfortunately apollo requires that...)
  assign_for_apollo(name_apollo_object = "database", value_object = data_wide )

  # Set core controls
  assign_for_apollo(
    name_apollo_object  = "apollo_control",
    value_object = list(
      modelName       = "MNL_starting_point",
      modelDescr      = "MNL",
      mixing          = FALSE,
      indivID         = "id_ind",
      nCores          = 1,
      outputDirectory = NULL
    )
  )
  # Apollo beta
  assign_for_apollo(
    name_apollo_object  = "apollo_beta",
    value_object = c(B_x1      =  -0.5,
                     B_x2      = -1)
  )
  # Fixed parameters (none)
  assign_for_apollo(
    name_apollo_object  = "apollo_fixed",
    value_object = c( )
  )
  # apollo validate inputs
  log <- utils::capture.output({

    apollo_inputs = apollo::apollo_validateInputs()
  })

  # Apollo choice probabilites MNL
  assign_for_apollo(
    name_apollo_object = "apollo_probabilities",
    value_object = function(apollo_beta,
                            apollo_inputs,
                            functionality="estimate"){
      ### Attach inputs and detach after function exit
      apollo::apollo_attach(apollo_beta, apollo_inputs)
      on.exit(apollo::apollo_detach(apollo_beta, apollo_inputs))
      ### Create list of probabilities P
      P = list()

      ### List of utilities: these must use the same names as in mnl_settings, order is irrelevant
      V = list()
      V[["alt1"]]  =  B_x1*x1_1 + B_x2*x2_1
      V[["alt2"]]  =  B_x1*x1_2 + B_x2*x2_2
      V[["alt3"]]  =  B_x1*x1_3 + B_x2*x2_3

      ### Define settings for MNL model component
      mnl_settings = list(
        alternatives = c(   alt1=1, alt2=2, alt3=3),
        avail        = list(alt1=1, alt2=1, alt3=1),
        choiceVar    = choice_wide,
        utilities     = V
      )


      ### Compute probabilities using MNL model
      P[["model"]] = apollo::apollo_mnl(mnl_settings, functionality)

      ### Take product across observation for same individual
      P = apollo::apollo_panelProd(P, apollo_inputs, functionality)

      ### Prepare and return outputs of function
      P = apollo::apollo_prepareProb(P, apollo_inputs, functionality)
      return(P)
      })
  # Estimate simple MNL model

  log <- utils::capture.output({

    MNL_model <-  apollo::apollo_estimate(
      apollo_beta,
      apollo_fixed,
      apollo_probabilities,
      apollo_inputs,
      estimate_settings = list(writeIter = FALSE))
  })


  # Remove overload of apollo_objects in the .GlobalEnv
  clear_apollo_overflow()

  cat("\n","MNL correctly estimated")

  return(MNL_model$estimate)

}
