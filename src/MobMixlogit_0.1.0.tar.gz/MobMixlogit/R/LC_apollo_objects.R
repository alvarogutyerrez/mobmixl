#' @export
#### Common functions ####
.apollo_fixed_LC_cte_only <- c(
  "asc3_a",
  "asc3_b",
  "delta_a"
)



#### LC 2 CLASSES ####
.apollo_lcPars_2C_cte_only  <- function(apollo_beta, apollo_inputs){
  lcpars = list()

  lcpars[["asc1"]]    = list(asc1_a, asc1_b)

  lcpars[["asc2"]]    = list(asc2_a, asc2_b)

  lcpars[["asc3"]]    = list(asc3_a, asc3_b)

  lcpars[["forest"]]    = list(forest_a, forest_b)

  lcpars[["morbidity"]] = list(morbidity_a, morbidity_b)

  lcpars[["land"]]      = list(land_a, land_b)

  lcpars[["location"]]      = list(location_a, location_b)

  lcpars[["cost"]]      = list(cost_a, cost_b)

  V=list()

  V[["class_a"]] = delta_a

  V[["class_b"]] = delta_b


  classAlloc_settings = list(
    classes      = c(class_a = 1,
                     class_b = 2),
    utilities    = V
  )

  lcpars[["pi_values"]] = apollo_classAlloc(classAlloc_settings)

  return(lcpars)
}





.apollo_probabilities_LC_2C <- function(apollo_beta, apollo_inputs, functionality="estimate"){

  ### Attach inputs and detach after function exit
  apollo_attach(apollo_beta, apollo_inputs)
  on.exit(apollo_detach(apollo_beta, apollo_inputs))

  ### Create list of probabilities P
  P = list()

  ### Define settings for MNL model component that are generic across classes
  mnl_settings = list(
    alternatives = c(   alt1=1, alt2=2, alt3=3),
    avail        = list(alt1=1, alt2=1, alt3=1),
    choiceVar    = choice
  )

  ### Loop over classes
  for(s in 1:2){
    ### Compute class-specific utilities
    V=list()

    V[["alt1"]]  = asc1[[s]] + forest[[s]]*forest.1 + morbidity[[s]]*morbidity.1 + land[[s]]*land.1 + cost[[s]]*cost.1 +  location[[s]]* location.1
    V[["alt2"]]  = asc2[[s]] + forest[[s]]*forest.2 + morbidity[[s]]*morbidity.2 + land[[s]]*land.2 + cost[[s]]*cost.2 +  location[[s]]* location.2
    V[["alt3"]]  = asc3[[s]] + forest[[s]]*forest.3 + morbidity[[s]]*morbidity.3 + land[[s]]*land.3 + cost[[s]]*cost.3 +  location[[s]]* location.3

    mnl_settings$utilities = V
    mnl_settings$componentName = paste0("Class_",s)

    ### Compute within-class choice probabilities using MNL model
    P[[paste0("Class_",s)]] = apollo_mnl(mnl_settings, functionality)

    ### Take product across observation for same individual
    P[[paste0("Class_",s)]] = apollo_panelProd(P[[paste0("Class_",s)]], apollo_inputs ,functionality)

  }

  ### Compute latent class model probabilities
  lc_settings  = list(inClassProb = P,
                      classProb   = pi_values)
  P[["model"]] = apollo_lc(lc_settings, apollo_inputs, functionality)

  ### Prepare and return outputs of function
  P = apollo_prepareProb(P, apollo_inputs, functionality)
  return(P)
}




.apollo_beta_LC_2C_cte_only <-  c(
  asc1_a            =  0,
  asc2_a            =  0.1,
  asc3_a            =  0,

  asc1_b            =  0,
  asc2_b            =  0.1,
  asc3_b            =  0,

  forest_a     =  -0.5,
  forest_b     =  -1,

  morbidity_a = -1,
  morbidity_b = -1,

  land_a = -0.01,
  land_b = -0.01,

  location_a = -0.01,
  location_b = -0.01,

  cost_a = -3,
  cost_b = -3,

  #Allocation model is cte_only
  delta_a = 0 ,
  delta_b = 0.01
  )





#### LC 3 CLASSES####

.apollo_lcPars_3C_cte_only <- function(apollo_beta, apollo_inputs){
  lcpars = list()

  lcpars[["asc1"]]    = list(asc1_a, asc1_b, asc1_c)

  lcpars[["asc2"]]    = list(asc2_a, asc2_b, asc2_c)

  lcpars[["asc3"]]    = list(asc3_a, asc3_b, asc3_c)

  lcpars[["forest"]]    = list(forest_a, forest_b, forest_c)

  lcpars[["morbidity"]] = list(morbidity_a, morbidity_b, morbidity_c)

  lcpars[["land"]]      = list(land_a, land_b, land_c)

  lcpars[["location"]]      = list(location_a, location_b, location_c)

  lcpars[["cost"]]      = list(cost_a, cost_b, cost_c)


  V=list()
  V[["class_a"]] = delta_a
  V[["class_b"]] = delta_b
  V[["class_c"]] = delta_c

  classAlloc_settings = list(
    classes      = c(class_a = 1,
                     class_b = 2,
                     class_c = 3),
    utilities    = V
  )

  lcpars[["pi_values"]] = apollo_classAlloc(classAlloc_settings)

  return(lcpars)
}




.apollo_probabilities_LC_3C <- function(apollo_beta, apollo_inputs, functionality="estimate"){

  ### Attach inputs and detach after function exit
  apollo_attach(apollo_beta, apollo_inputs)
  on.exit(apollo_detach(apollo_beta, apollo_inputs))

  ### Create list of probabilities P
  P = list()

  ### Define settings for MNL model component that are generic across classes
  mnl_settings = list(
    alternatives = c(   alt1=1, alt2=2, alt3=3),
    avail        = list(alt1=1, alt2=1, alt3=1),
    choiceVar    = choice
  )

  ### Loop over classes
  for(s in 1:3){
    ### Compute class-specific utilities
    V=list()

    V[["alt1"]]  = asc1[[s]] + forest[[s]]*forest.1 + morbidity[[s]]*morbidity.1 + land[[s]]*land.1 + cost[[s]]*cost.1 +  location[[s]]* location.1
    V[["alt2"]]  = asc2[[s]] + forest[[s]]*forest.2 + morbidity[[s]]*morbidity.2 + land[[s]]*land.2 + cost[[s]]*cost.2 +  location[[s]]* location.2
    V[["alt3"]]  = asc3[[s]] + forest[[s]]*forest.3 + morbidity[[s]]*morbidity.3 + land[[s]]*land.3 + cost[[s]]*cost.3 +  location[[s]]* location.3

    mnl_settings$utilities = V
    mnl_settings$componentName = paste0("Class_",s)

    ### Compute within-class choice probabilities using MNL model
    P[[paste0("Class_",s)]] = apollo_mnl(mnl_settings, functionality)

    ### Take product across observation for same individual
    P[[paste0("Class_",s)]] = apollo_panelProd(P[[paste0("Class_",s)]], apollo_inputs ,functionality)

  }

  ### Compute latent class model probabilities
  lc_settings  = list(inClassProb = P,
                      classProb   = pi_values)
  P[["model"]] = apollo_lc(lc_settings, apollo_inputs, functionality)

  ### Prepare and return outputs of function
  P = apollo_prepareProb(P, apollo_inputs, functionality)
  return(P)
}



.apollo_beta_LC_3C_cte_only <- c(
  asc1_a  =  0,
  asc2_a  =  0.1,
  asc3_a  =  0,

  asc1_b  =  0,
  asc2_b  =  0.1,
  asc3_b  =  0,

  asc1_c  =  0,
  asc2_c  =  0.1,
  asc3_c  =  0,


  forest_a  =  -0.5,
  forest_b  =  -1,
  forest_c  =  -1,

  morbidity_a = -1,
  morbidity_b = -1,
  morbidity_c = -1,

  cost_a = -3,
  cost_b = -3,
  cost_c = -3,


  land_a = -0.01,
  land_b = -0.01,
  land_c = -0.01,

  location_a = -0.01,
  location_b = -0.01,
  location_c = -0.01,

  #Allocation model cte only
  delta_a = 0 ,
  delta_b = 0.01,
  delta_c = 0)



#### LC-MIXL 2 CLASSES ####

.apollo_draws_LC_MIXL <- function(N_draws = 2){

  res <- list(interDrawsType= "halton",
              interNDraws   = N_draws,
              interUnifDraws= c("U_cost_a"     , "U_cost_b"),
              interNormDraws=c("N_forest","N_morbidity"),

              intraDrawsType="mlhs",
              intraNDraws   =0,
              intraUnifDraws=c(),
              intraNormDraws=c()
              )
  return(res)

}

.apollo_randCoeff_LC_MIXL_2C <- function(apollo_beta, apollo_inputs){
  randcoeff = list()

  randcoeff[["forest_a"]] = forest_mu_a  + forest_sd_a * N_forest
  randcoeff[["forest_b"]] = forest_mu_b  + forest_sd_b * N_forest

  randcoeff[["morbidity_a"]] = morbidity_mu_a  + morbidity_sd_a *N_morbidity
  randcoeff[["morbidity_b"]] = morbidity_mu_b  + morbidity_sd_b *N_morbidity

  randcoeff[["cost_a"]] = cost_scale_a + cost_scale_a*((U_cost_a + U_cost_b)*0.5)
  randcoeff[["cost_b"]] = cost_scale_b + cost_scale_b*((U_cost_a + U_cost_b)*0.5)

  return(randcoeff)
}



.apollo_probabilities_LC_MIXL_2C <- function(apollo_beta, apollo_inputs, functionality="estimate"){

  ### Attach inputs and detach after function exit
  apollo_attach(apollo_beta, apollo_inputs)
  on.exit(apollo_detach(apollo_beta, apollo_inputs))

  ### Create list of probabilities P
  P = list()

  ### Define settings for MNL model component that are generic across classes
  mnl_settings = list(
    alternatives = c(   alt1=1, alt2=2, alt3=3),
    avail        = list(alt1=1, alt2=1, alt3=1),
    choiceVar    = choice
  )

  ### Loop over classes
  for(s in 1:2){
    ### Compute class-specific utilities
    V=list()

    V[["alt1"]]  = asc1[[s]] + forest[[s]]*forest.1 + morbidity[[s]]*morbidity.1 + land[[s]]*land.1 + cost[[s]]*cost.1 +  location[[s]]* location.1
    V[["alt2"]]  = asc2[[s]] + forest[[s]]*forest.2 + morbidity[[s]]*morbidity.2 + land[[s]]*land.2 + cost[[s]]*cost.2 +  location[[s]]* location.2
    V[["alt3"]]  = asc3[[s]] + forest[[s]]*forest.3 + morbidity[[s]]*morbidity.3 + land[[s]]*land.3 + cost[[s]]*cost.3 +  location[[s]]* location.3

    mnl_settings$utilities = V
    mnl_settings$componentName = paste0("Class_",s)

    ### Compute within-class choice probabilities using MNL model
    P[[paste0("Class_",s)]] = apollo_mnl(mnl_settings, functionality)

    ### Take product across observation for same individual
    P[[paste0("Class_",s)]] = apollo_panelProd(P[[paste0("Class_",s)]], apollo_inputs ,functionality)

    ### Average across inter-individual draws within classes
    P[[paste0("Class_",s)]] = apollo_avgInterDraws(P[[paste0("Class_",s)]], apollo_inputs, functionality)
  }

  ### Compute latent class model probabilities
  lc_settings  = list(inClassProb = P,
                      classProb   = pi_values)
  P[["model"]] = apollo_lc(lc_settings, apollo_inputs, functionality)

  ### Prepare and return outputs of function
  P = apollo_prepareProb(P, apollo_inputs, functionality)
  return(P)
}



.apollo_beta_LC_MIXL_2C_cte_only <- c(
  asc1_a            =  0,
  asc2_a            =  0.1,
  asc3_a            =  0,

  asc1_b            =  0,
  asc2_b            =  0.1,
  asc3_b            =  0,

  forest_mu_a     =  -0.5,
  forest_mu_b     =  -1,

  forest_sd_a     =  -0.5,
  forest_sd_b     =  -1,

  morbidity_mu_a = -1,
  morbidity_mu_b = -1,

  morbidity_sd_a = -1,
  morbidity_sd_b = -1,


  land_a = -0.01,
  land_b = -0.01,

  location_a = -0.01,
  location_b = -0.01,

  cost_scale_a = -3,
  cost_scale_b = -3,

  # Allocation Model is cte only
  delta_a = 0 ,
  delta_b = 0.01 )





#### LC-MIXL 3 CLASSES ####

.apollo_probabilities_LC_MIXL_3C <- function(apollo_beta, apollo_inputs, functionality="estimate"){

  ### Attach inputs and detach after function exit
  apollo_attach(apollo_beta, apollo_inputs)
  on.exit(apollo_detach(apollo_beta, apollo_inputs))

  ### Create list of probabilities P
  P = list()

  ### Define settings for MNL model component that are generic across classes
  mnl_settings = list(
    alternatives = c(   alt1=1, alt2=2, alt3=3),
    avail        = list(alt1=1, alt2=1, alt3=1),
    choiceVar    = choice
  )

  ### Loop over classes
  for(s in 1:3){
    ### Compute class-specific utilities
    V=list()

    V[["alt1"]]  = asc1[[s]] + forest[[s]]*forest.1 + morbidity[[s]]*morbidity.1 + land[[s]]*land.1 + cost[[s]]*cost.1 +  location[[s]]* location.1
    V[["alt2"]]  = asc2[[s]] + forest[[s]]*forest.2 + morbidity[[s]]*morbidity.2 + land[[s]]*land.2 + cost[[s]]*cost.2 +  location[[s]]* location.2
    V[["alt3"]]  = asc3[[s]] + forest[[s]]*forest.3 + morbidity[[s]]*morbidity.3 + land[[s]]*land.3 + cost[[s]]*cost.3 +  location[[s]]* location.3

    mnl_settings$utilities = V
    mnl_settings$componentName = paste0("Class_",s)

    ### Compute within-class choice probabilities using MNL model
    P[[paste0("Class_",s)]] = apollo_mnl(mnl_settings, functionality)

    ### Take product across observation for same individual
    P[[paste0("Class_",s)]] = apollo_panelProd(P[[paste0("Class_",s)]], apollo_inputs ,functionality)

    ### Average across inter-individual draws within classes
    P[[paste0("Class_",s)]] = apollo_avgInterDraws(P[[paste0("Class_",s)]], apollo_inputs, functionality)
  }

  ### Compute latent class model probabilities
  lc_settings  = list(inClassProb = P,
                      classProb   = pi_values)
  P[["model"]] = apollo_lc(lc_settings, apollo_inputs, functionality)

  ### Prepare and return outputs of function
  P = apollo_prepareProb(P, apollo_inputs, functionality)
  return(P)
}



.apollo_randCoeff_LC_MIXL_3C <- function(apollo_beta, apollo_inputs){
  randcoeff = list()

  randcoeff[["forest_a"]] = forest_mu_a  + forest_sd_a * N_forest
  randcoeff[["forest_b"]] = forest_mu_b  + forest_sd_b * N_forest
  randcoeff[["forest_c"]] = forest_mu_c  + forest_sd_c * N_forest

  randcoeff[["morbidity_a"]] = morbidity_mu_a  + morbidity_sd_a * N_morbidity
  randcoeff[["morbidity_b"]] = morbidity_mu_b  + morbidity_sd_b * N_morbidity
  randcoeff[["morbidity_c"]] = morbidity_mu_c  + morbidity_sd_c * N_morbidity


  randcoeff[["cost_a"]] = cost_scale_a + cost_scale_a*((U_cost_a + U_cost_b)*0.5)
  randcoeff[["cost_b"]] = cost_scale_b + cost_scale_b*((U_cost_a + U_cost_b)*0.5)
  randcoeff[["cost_c"]] = cost_scale_c + cost_scale_c*((U_cost_a + U_cost_b)*0.5)


  return(randcoeff)
}





.apollo_beta_LC_MIXL_3C_cte_only <- c(
  asc1_a            =  0,
  asc2_a            =  0.1,
  asc3_a            =  0,

  asc1_b            =  0,
  asc2_b            =  0.1,
  asc3_b            =  0,

  asc1_c            =  0,
  asc2_c           =  0.1,
  asc3_c            =  0,

  forest_mu_a     =  -0.5,
  forest_mu_b     =  -1,
  forest_mu_c     =  -1,

  forest_sd_a     =  -0.5,
  forest_sd_b     =  -1,
  forest_sd_c     =  -1,


  morbidity_mu_a = -1,
  morbidity_mu_b = -1,
  morbidity_mu_c = -1,


  morbidity_sd_a = -1,
  morbidity_sd_b = -1,
  morbidity_sd_c = -1,


  cost_scale_a = -3,
  cost_scale_b = -3,
  cost_scale_c = -3,


  land_a = -0.01,
  land_b = -0.01,
  land_c = -0.01,

  location_a = -0.01,
  location_b = -0.01,
  location_c = -0.01,

  # Allocation Model (constant only)
  delta_a = 0 ,
  delta_b = 0.01,
  delta_c = 0)




