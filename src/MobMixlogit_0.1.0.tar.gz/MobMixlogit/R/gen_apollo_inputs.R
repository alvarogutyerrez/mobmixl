#' @export
gen_apollo_inputs <- function() {

  # Set core controls
  assign_for_apollo(
    name_apollo_object  = "apollo_control",
    value_object = list(
      modelName       = "3_CLASS_LC_MMNL",
      modelDescr      = "LC MM 3 classes using simulated data",
      mixing          = TRUE,
      HB              = FALSE,
      indivID         = "id_ind",
      nCores          = 1 ))


  # Vector with names (in quotes) of parameters to be kept fixed at their starting value in apollo_beta, use apollo_beta_fixed = c() if none
  assign_for_apollo(
    name_apollo_object  = "apollo_fixed",
    value_object = c("delta_a"   ,
                     "gamma_a_z1",
                     "gamma_a_z2",
                     "gamma_a_z3",
                     "gamma_a_z4",
                     "gamma_a_z5"
    )
  )

  ### Set parameters for generating draws
  assign_for_apollo(
    name_apollo_object  = "apollo_draws",
    value_object =  list(
      interDrawsType = "sobol",
      interNDraws    = 1000,
      interUnifDraws = c(),
      interNormDraws = c("draws_x1", "draws_x2"),

      intraDrawsType = "mlhs",
      intraNDraws    = 0,
      intraUnifDraws = c(),
      intraNormDraws = c()
    )

  )


  ### Create random parameters

  assign_for_apollo(
    name_apollo_object  = "apollo_randCoeff",
    value_object =  function(apollo_beta,
                             apollo_inputs){
      randcoeff = list()

      randcoeff[["x1_a"]] = x1_a_mu  + x1_a_sd*draws_x1
      randcoeff[["x1_b"]] = x1_b_mu  + x1_b_sd*draws_x1
      randcoeff[["x1_c"]] = x1_c_mu  + x1_c_sd*draws_x1

      randcoeff[["x2_a"]] = x2_a_mu  + x2_a_sd*draws_x2
      randcoeff[["x2_b"]] = x2_b_mu  + x2_b_sd*draws_x2
      randcoeff[["x2_c"]] = x2_c_mu  + x2_c_sd*draws_x2

      return(randcoeff)
    }

  )



  # ################################################################# #
  #### DEFINE LATENT CLASS COMPONENTS                              ####
  # ################################################################# #


  assign_for_apollo(
    name_apollo_object  = "apollo_lcPars",
    value_object =  function(apollo_beta, apollo_inputs){
      lcpars = list()
      lcpars[["x1"]]    = list(x1_a, x1_b, x1_c)
      lcpars[["x2"]]    = list(x2_a, x2_b, x2_c)
      V = list()

      V[["class_a"]] = delta_a +
        gamma_a_z1 * z1 +
        gamma_a_z2 * z2 +
        gamma_a_z3 * z3 +
        gamma_a_z4 * z4 +
        gamma_a_z5 * z5

      V[["class_b"]] = delta_b +
        gamma_b_z1 * z1 +
        gamma_b_z2 * z2 +
        gamma_b_z3 * z3 +
        gamma_b_z4 * z4 +
        gamma_b_z5 * z5

      V[["class_c"]] = delta_c +
        gamma_c_z1 * z1 +
        gamma_c_z2 * z2 +
        gamma_c_z3 * z3 +
        gamma_c_z4 * z4 +
        gamma_c_z5 * z5


      classAlloc_settings = list(
        classes      = c(class_a = 1, class_b = 2, class_c = 3),
        utilities    = V
      )

      lcpars[["pi_values"]] = apollo_classAlloc(classAlloc_settings)

      return(lcpars)
    }
    )


  return(FALSE)


}

