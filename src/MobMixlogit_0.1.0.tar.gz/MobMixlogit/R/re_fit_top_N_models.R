#' @importFrom apollo apollo_validateInputs apollo_attach apollo_detach apollo_mnl apollo_panelProd apollo_prepareProb apollo_estimate
#' @importFrom stats setNames
#' @importFrom dplyr select starts_with
#' @export

re_fit_top_N_models<- function(best_N_models,
                               apollo_beta,
                               apollo_fixed,
                               apollo_probabilities,
                               apollo_inputs,
                               max_iter_final_models = 400
                               ){

  top_N_models <- lapply(seq_along(best_N_models),
                        function(i){

                          # Estimate the model
                          cat("\n","Estimating","final number ",i," model...","\n")

                          #log <- utils::capture.output({

                          assign_for_apollo(
                            name_apollo_object  = "apollo_beta",
                            value_object    = best_N_models[[i]]
                          )

                          apollo_beta <- best_N_models[[i]]

                          log <- utils::capture.output({

                            # database object in .GlovEnv (unfortunately apollo requires that...)
                            apollo_inputs = apollo::apollo_validateInputs()


                            assign_for_apollo(
                              name_apollo_object  = "apollo_inputs",
                              value_object    = apollo_inputs
                            )

                            # Final model (including std.errors)
                            final_model = apollo::apollo_estimate(
                              apollo_beta = apollo_beta,
                              apollo_fixed = apollo_fixed ,
                              apollo_probabilities = apollo_probabilities,
                              apollo_inputs = apollo_inputs,
                              estimate_settings = list(hessianRoutine = "numDeriv",
                                                       writeIter = FALSE,
                                                       maxIterations=max_iter_final_models))
                          })

                          # Recompute class-membershipt after estimating the final model
                          class_membership <- gen_info_model(model = final_model,
                                                         apollo_inputs = apollo_inputs ,
                                                         apollo_probabilities = apollo_probabilities
                                                         ) %>%
                              t() %>%
                              as.data.frame() %>%
                              dplyr::select(dplyr::starts_with("class_"))


                          # Final model + class membership
                          final_model_and_class_membership <- list(
                            final_model = final_model,
                            class_membership = class_membership
                            )

                          cat("\n","Log-Likelihood top ",i, "model","",final_model$maximum,"\n")

                          return(final_model_and_class_membership)


                        })

  return(top_N_models)

}
