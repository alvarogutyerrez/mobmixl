#' @importFrom stats rbinom  rnorm runif
#' @export
dgp_stump <-function(N   = 100,
                     t = 10 ,
                     J   = 3,
                     xi  = 0.5,
                     delta = 1 ,
                     round_decimals = 1,
                     b1_mu = 1 , b1_sd = 0.5,
                     b2_mu = 1 , b2_sd = 0.5,
                     seed = 0
){
  # set seed
  set.seed(seed)
  # -----------------------#
  ####  Data Generation ####
  # -----------------------#

  # id of every choice situation (without considering the individual who answered it)
  id <- rep(1:(N*t), each = J )

  # id for individuals
  id_ind <- rep(1:N, each = J * t)

  # id for individuals
  id_choice_situation_of_individual_n <- rep(1:t, each = J, times = N)

  # Number of the alternative
  altern <- rep(1:(J), times = N*t )


  # Generate variables that depend on T
  x1 <- stats::rnorm(N * J * t)
  x2 <- stats::rnorm(N * J * t)

  # Partition Variables
  z1 = round( stats::runif(n = N, 0, 1), round_decimals)
  z2 = round( stats::runif(n = N, 0, 1), round_decimals)
  z3 = round( stats::runif(n = N, 0, 1), round_decimals)
  z4 = round( stats::runif(n = N, 0, 1), round_decimals)
  z5 = round( stats::runif(n = N, 0, 1), round_decimals)

  # Random Parameters
  beta1 <-  (b1_mu + delta*(z1 > xi)) + b1_sd * stats::rnorm(N)
  beta2 <-  (b2_mu + delta*(z1 > xi)) + b2_sd * stats::rnorm(N)


  # Expanding to the total number of choice situations
  beta1 <- beta1[id_ind]
  beta2 <- beta2[id_ind]

  # The true data generating process
  U  =  beta1 * x1 + beta2 * x2 - log(-log(stats::runif(N * J * t)))

  ## Chosen alternative
  chosen <- rep(0, N * t * J)
  for (i in 1:(N * t)) {
    U_j   <- U[((i - 1) * J + 1):(i * J)]
    U_max <- max(U_j)
    pos   <- which(U_j == U_max)
    chosen[((i - 1) * J + 1):(i * J)][pos] <- TRUE
  }

  # Expanding individual-specific variables
  z1 <- z1[id_ind]
  z2 <- z2[id_ind]
  z3 <- z3[id_ind]
  z4 <- z4[id_ind]
  z5 <- z5[id_ind]

  # Generate a data to be used when fitting the models
  data <- as.data.frame(cbind(id,
                              id_ind ,
                              id_choice_situation_of_individual_n,
                              altern,
                              chosen,
                              x1, x2,
                              z1,z2,z3,z4,z5,beta1,beta2))

  ## Different betas for different people based on z1>xi
  data$leaf <- numeric(length(data$z1))
  # leaf =
  #       2 means z1 <= xi
  #       3 means z1 > xi

  data$leaf <-  2L + 1L*(data$z1 > xi)

  return(data)

}

