#' @export
.modify_apollo_beta <- function(apollo_beta_to_modify,
                               alloc_model_vars,
                               N_classes,
                               param_names_prefix = "gamma"){



  list_of_extra_apollo_beta <- lapply(
    letters[1:N_classes],
    function(class_c){lapply(
      alloc_model_vars,
      function(i){
        paste0(param_names_prefix,"_",class_c,"_",i )})
    })

  names_extra_apollo_beta <- unlist(list_of_extra_apollo_beta)

  extra_apollo_beta <- rep(0,length(names_extra_apollo_beta))


  names(extra_apollo_beta) <- names_extra_apollo_beta

  apollo_beta_full <- c(apollo_beta_to_modify,extra_apollo_beta )

  return(apollo_beta_full)
}


