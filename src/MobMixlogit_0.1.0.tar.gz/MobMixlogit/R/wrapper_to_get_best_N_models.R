#' @export
wrapper_to_get_best_N_models <- function(nCandidates,
                                         N_best_models,
                                         max_iter_search_vals  = 400,
                                         max_iter_final_models = 400,
                                         apollo_beta,
                                         apollo_fixed,
                                         apollo_probabilities,
                                         apollo_inputs
                                            ){

  if (nCandidates < N_best_models) {
    stop("Number of 'N_best_models' has to be smaller than 'nCandidates' ")

  }

  # Starting points.
  candidates <- create_candidates(
    apollo_beta,
    apollo_fixed,
    nCandidates = nCandidates,
    apolloBetaMin = apollo_beta - 1.5,
    apolloBetaMax = apollo_beta + 1.5)

  cat("\n",nCandidates,"different starting points created","\n")

  # Fit the model to all possible candidates
  fitted_possible_candidates <- fit_model_to_all_candidates(
    candidates = candidates,
    apollo_beta = apollo_beta,
    apollo_fixed = apollo_fixed,
    apollo_probabilities = apollo_probabilities,
    apollo_inputs = apollo_inputs,
    max_iter_search_vals = max_iter_search_vals
  )

  # Get Best N model from the fitted models
  best_N_models <- get_best_N_models(
    df = fitted_possible_candidates,
    apollo_beta = apollo_beta,
    N_best_models = N_best_models
  )

  # Re-fit (with std.errors) best N models
  top_N_models <- re_fit_top_N_models(
    best_N_models = best_N_models,
    apollo_beta = apollo_beta,
    apollo_fixed = apollo_fixed,
    apollo_probabilities = apollo_probabilities,
    apollo_inputs = apollo_inputs,
    max_iter_final_models = max_iter_final_models
  )

  # Final object
  res <- list(
    top_N_models = top_N_models,
    fitted_possible_candidates = fitted_possible_candidates
  )

  return(res)

}
