#' @importFrom parallel makeCluster clusterSetRNGStream clusterEvalQ clusterExport
#' @importFrom pbapply pblapply
#' @export
simwrapper <- function(n.indiv   =   c(75),
                       n.choices =   c( 5 ) ,
                       xi        =   c(0.5, 0.8 ) ,
                       delta     =   c( 0.5, 1 ),
                       nrep      =  2,
                       scenario  = c("tree","stump"),
                       draws     = 10 ,
                       seed      = 0,
                       run_in_parallel  = FALSE,
                       nClusters = 2)
{
  prs <- expand.grid(n.indiv   = n.indiv,
                     n.choices = n.choices,
                     xi        = xi,
                     delta     = delta,
                     scenario  = scenario)
  print(prs)
  rownames(prs) <- c(1:NROW(prs))
  nprs <- nrow(prs)


  if (run_in_parallel) {
    # Parallel options
    # Number of clusters/cores
    cl <- parallel::makeCluster(nClusters)

    # Set.seet in parallel cluster
    parallel::clusterSetRNGStream(cl, iseed = 123456789L)

    # Attaching necessary functions for internal computations +  p-values of the supLM test
    fn_from_simulations <- list("sim",
                                "dgp_tree",
                                "dgp_stump",
                                "adj_rand_index")
    # Attach functions to the cluster.
    parallel::clusterExport(cl= cl,
                            fn_from_simulations)
    ## Attaching necessary packages to the cluster
    parallel::clusterEvalQ(cl = cl, list(library(mlogit),
                                         library(partykit)))

    #Parallel call
    simres <-  pbapply::pblapply(cl  = cl,
                            X   = 1:nprs,
                            FUN= function(i){
                              sim( nrep      = nrep,
                                   draws     = draws,
                                   scenario  = prs$scenario[i]  ,
                                   xi        = prs$xi[i]        ,
                                   delta     = prs$delta[i]     ,
                                   n.indiv   = prs$n.indiv[i]   ,
                                   n.choices = prs$n.choices[i] ,
                                   seed = seed)})
    ##exit cluster mode
    parallel::stopCluster(cl)

  } else {
    simres <- lapply(1:nprs,
                   FUN = function(i){
                     sim(nrep      = nrep            ,
                         draws     = draws           ,
                         scenario  = prs$scenario[i]  ,
                         xi        = prs$xi[i]        ,
                         delta     = prs$delta[i]     ,
                         n.indiv   = prs$n.indiv[i]   ,
                         n.choices = prs$n.choices[i] ,
                         seed = seed)}
                   )
  }


  return(simres)
}
