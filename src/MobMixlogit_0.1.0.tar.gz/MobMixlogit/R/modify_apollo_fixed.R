#' @export
.modify_apollo_fixed <- function(.apollo_fixed,
                                 N_classes,
                                alloc_model_vars = NULL,
                                param_names_prefix ="gamma"){

  if (N_classes==3) {

    if (!is.null(alloc_model_vars)) {

      list_new_fixed_params <- lapply(alloc_model_vars,
                                      function(i){paste0(param_names_prefix,"_a_",i )})

      res <- c(.apollo_fixed, "asc3_c", unlist(list_new_fixed_params))
    } else {
        res <- c(.apollo_fixed, "asc3_c" )
    }
  } else if(N_classes==2) {

    if (!is.null(alloc_model_vars)) {

      list_new_fixed_params <- lapply(alloc_model_vars,
                                      function(i){paste0(param_names_prefix,"_a_",i )})

      res <- c(.apollo_fixed, unlist(list_new_fixed_params))
    } else {

      res <- .apollo_fixed
    }

  }

  return(res)
}



