#' @importFrom stats rbinom  rnorm runif rmultinom
#' @importFrom magrittr "%>%"
#' @importFrom dplyr group_by mutate case_when
#' @export
dgp_LC_3 <- function(N = 400,
                     t = 12 ,
                     J = 3  ,
                     gamma_c1 = c(0,0,0,0,0),
                     gamma_c2 = c(1,1,1,1,1),
                     gamma_c3 = c(-1,-1,-1,-1,-1),
                     ctes = c(0,1,-1),
                     all_beta1 = c(-1,-2,-3),
                     all_beta2 = c(3,2,1  ),
                     seed = 0)

{
  set.seed(seed)
  ## Individual Specific Attributes
  mX <- matrix(round(stats::rnorm(N*5), digits = 2), N, 5)
  colnames(mX) <- c("z1", "z2", "z3", "z4", "z5")
  ## Exp of linear combination of the allocation model
  ExpXGamma <- cbind(exp(mX%*%gamma_c1 + ctes[1]),
                     exp(mX%*%gamma_c2 + ctes[2]),
                     exp(mX%*%gamma_c3 + ctes[3]))
  ## True probability of belonging to each class
  prob <- ExpXGamma/rowSums(ExpXGamma)
  ## Multinomial sampling over the true probabilities of each class.
  mChoices <- t(apply(X = prob,
                      MARGIN = 1,
                      FUN =  stats::rmultinom,
                      n = 1,
                      size = 1)) #multinomial sampling

  df_ind_characteristics = cbind.data.frame(
    class = apply(X      = mChoices,
                  MARGIN = 1,
                  FUN    = function(x) which(x==1)),
    mX,
    id_ind=  1:N)

  #test <- multinom(formula = class~ 1 + z1 + z2 +  z3 + z4 + z5 ,
  #                 data = df_ind_characteristics)
  # You can check here that I am recoverting the gamma vectors


  #### Creating the choice data ####

  # id of every choice situation (without considering the individual who answered it)
  id <- rep(1:(N*t), each = J )

  # id for individuals
  id_ind <- rep(1:N, each = J * t)

  # id for individuals
  id_choice <- rep(1:t, each = J, times = N)

  # Number of the alternative
  altern <- rep(1:(J), times = N*t )


  # Generate variables that depend on T
  x1 <- stats::rnorm(N * J * t)
  x2 <- stats::rnorm(N * J * t)

  df <- cbind(id,
              id_ind,
              id_choice,
              altern,
              x1,x2)

  df <- merge(df, df_ind_characteristics, by = "id_ind")


  #### Declaring betas of each class ####
  df <- df %>%
    dplyr::mutate(
      beta1 = dplyr::case_when(
        class== 1 ~  all_beta1[1],
        class== 2 ~  all_beta1[2],
        class== 3 ~  all_beta1[3],
        TRUE ~ 99999),
      beta2 = dplyr::case_when(
        class== 1  ~ all_beta2[1],
        class== 2 ~  all_beta2[2],
        class== 3 ~  all_beta2[3],
        TRUE ~ 99999)
    )

  ## Create linear combination of utility
  df$V <- with(df,  beta1*x1 +    beta2 * x2 )

  ###########################
  #### Choice generator #####
  ###########################
  df <- df %>%
    dplyr::group_by(id) %>%
    dplyr::mutate(choice_long = stats::rmultinom(1, 1, (exp(V) / sum(exp(V)))))  %>%
    dplyr::ungroup()

  df$V <- NULL

  cat("Data generated for ",N,"\n",
      "Individuals answering ",t,"\n",
      "choice sets each")

  return(as.data.frame(df))
}

