#' @export
.modify_.apollo_lcPars <- function(.apollo_lcPars_to_modify,
                                   N_classes,
                                      alloc_model_vars = c("income",
                                                           "nvisits" ,
                                                           "age" ,
                                                           "elec_bill" ,
                                                           "signed_oath"),
                                      param_names_prefix ="gamma"){


  for (class_id in letters[1:N_classes]) {


    all_var_for_class_c <- lapply(alloc_model_vars,
                                      function(id){
                                        paste0(param_names_prefix,"_",class_id,"_",id," * ",id)})

    all_allocation_model_class_c <- paste(all_var_for_class_c, collapse = ' + ')

    class_cte  <- paste0("V[['class_",class_id,"']] = delta_",class_id[1])

    final_model_alloc_model_class_c <- paste(class_cte,all_allocation_model_class_c,sep = " + ")

    # Modify the existing allocation models
    if (class_id=="a") {
      body(.apollo_lcPars_to_modify)[[12]] <-  str2lang(final_model_alloc_model_class_c)
    }else if (class_id=="b") {
      body(.apollo_lcPars_to_modify)[[13]] <-  str2lang(final_model_alloc_model_class_c)
    }else if (class_id=="c") {
      body(.apollo_lcPars_to_modify)[[14]] <-  str2lang(final_model_alloc_model_class_c)
    }
  }


  return(.apollo_lcPars_to_modify)

}
