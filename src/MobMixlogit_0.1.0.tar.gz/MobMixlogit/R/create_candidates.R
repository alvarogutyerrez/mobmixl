#' @importFrom apollo apollo_mlhs
#' @export
create_candidates <- function(apollo_beta,
                              apollo_fixed,
                              nCandidates =10,
                              seed = 123456L,
                              apolloBetaMin = apollo_beta - 1.5,
                              apolloBetaMax = apollo_beta + 1.5){

  beta_var_val <- apollo_beta
  beta_fix_val <- apollo_beta[apollo_fixed]
  K <- length(beta_var_val)
  set.seed(seed)

  ## List with possible candidates
  candidates <- list()

  apolloBetaMin <- apolloBetaMin[names(beta_var_val)]
  apolloBetaMax <- apolloBetaMax[names(beta_var_val)]
  candidates[[1]] <- t(apollo::apollo_mlhs(nCandidates - 1, K,1))

  candidates[[1]] <- apolloBetaMin + (apolloBetaMax - apolloBetaMin) * candidates[[1]]
  candidates[[1]] <- cbind(beta_var_val, candidates[[1]])
  #new keeping fixed values at 0!

  candidates[[1]][apollo_fixed,]     <- 0
  candidates[[1]] <- cbind(beta_fix_val, candidates[[1]])
  candidates[[1]] <- t(candidates[[1]])

  return(candidates)
}
