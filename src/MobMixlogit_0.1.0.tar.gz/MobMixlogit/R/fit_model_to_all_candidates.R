#' @importFrom apollo apollo_validateInputs apollo_attach apollo_detach apollo_mnl apollo_panelProd apollo_prepareProb apollo_estimate
#' @importFrom utils capture.output
#' @export
fit_model_to_all_candidates <- function(candidates,
                                        max_iter_search_vals = 400,
                                        apollo_beta,
                                        apollo_fixed,
                                        apollo_probabilities,
                                        apollo_inputs,
                                        N_draws_search_init = 1000){

  #List to store different runs
  nCandidates <- length(candidates[[1]][,1]) - 1

  LL <- vector(mode = "list",  length = nCandidates)
  for (j in 1:nCandidates) {

    # Select candidate for starting values
    beta_test <- as.vector(candidates[[1]][j, ])
    names(beta_test) <- names(apollo_beta)

    # The following clunky way of assigning "apollo_beta" is due to
    # a *bug* in apollo (0.2.7) which I reported here:
    #http://www.apollochoicemodelling.com/forum/viewtopic.php?f=5&t=452

    apollo_beta <- beta_test
    #assign it also in the .GlobalEnv
    assign_for_apollo(
      name_apollo_object  = "apollo_beta",
      value_object    = beta_test
    )


    log <- utils::capture.output({
      apollo_inputs = apollo::apollo_validateInputs()
    })

    assign_for_apollo(
      name_apollo_object  = "apollo_inputs",
      value_object    = apollo_inputs
    )


    log <- utils::capture.output({

      model = apollo::apollo_estimate(
        apollo_beta,
        apollo_fixed,
        apollo_probabilities,
        apollo_inputs,
        estimate_settings = list(hessianRoutine = "none",
                                 writeIter = FALSE,
                                 maxIterations = max_iter_search_vals))

    })

    # Print maximum value iteration "j"
    cat("\n","Log-likelihood","iteration",j,":",model$maximum,"\n")

    # Iteration Number
    iter_j <-   j ; names(iter_j) <- "Iteration"
    # Save information the model
    info_model  <- gen_info_model(model, apollo_inputs, apollo_probabilities)
    # Save results
    LL[[j]] <- c(iter_j, info_model)
  }

  # Information of all models.
  df <-  data.frame(Reduce(rbind, LL))
  # Sort by Log-Likelihood
  df <-  df[order(df$LL,decreasing = TRUE),]


  return(df)
}
