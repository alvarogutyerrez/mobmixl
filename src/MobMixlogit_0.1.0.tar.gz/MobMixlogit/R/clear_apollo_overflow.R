clear_apollo_overflow <- function(){

  #Remove overflow of apollo objects that need to be stored in the .GlobalEnv.
  rm(apollo_control,
     apollo_beta,
     apollo_fixed,
     apollo_probabilities,
     database,
     apollo_lcPars,
     apollo_randCoeff,
     apollo_draws,
     apollo_inputs,
     envir = .GlobalEnv)

  rm(apollo_control,
     apollo_beta,
     apollo_fixed,
     apollo_probabilities,
     database)

}
