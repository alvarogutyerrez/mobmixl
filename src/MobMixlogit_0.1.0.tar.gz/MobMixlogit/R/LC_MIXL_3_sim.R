#' @importFrom apollo apollo_validateInputs apollo_attach apollo_detach apollo_mnl apollo_panelProd apollo_prepareProb apollo_estimate
#' @importFrom utils capture.output
#' @importFrom stats setNames
#' @export
LC_MIXL_3_sim <- function(data_wide,
                         N_cores = 1,
                         init_values_for_classes,
                         N_draws,
                         nCandidates = 2,
                         max_iter_search_vals = 40,
                         max_iter_final_models = 50,
                         N_best_models  = 1,
                         outliers = 500){



  # Remove overload of apollo_objects in the .GlobalEnv
  clear_apollo_overflow()

  # database object in .GlovEnv (unfortunately apollo requires that...)
  assign_for_apollo(name_apollo_object = "database", value_object = data_wide )

  # Set core controls
  assign_for_apollo(
    name_apollo_object  = "apollo_control",
    value_object = list(
      modelName       = "LC_MMNL",
      modelDescr      = "LC 3",
      mixing          = TRUE,
      indivID         = "id_ind",
      nCores          = N_cores
    )
  )

  # Set core controls
  assign_for_apollo(
    name_apollo_object  = "apollo_beta",
    value_object = c(

      x1_mu_a     =  -0.5,
      x1_mu_b     =  -1,
      x1_mu_c     =  -1,

      x1_sd_a     =  -0.5,
      x1_sd_b     =  -1,
      x1_sd_c     =  -1,


      x2_mu_a     =  -0.5,
      x2_mu_b     =  -1,
      x2_mu_c     =  -1,

      x2_sd_a     =  -0.5,
      x2_sd_b     =  -1,
      x2_sd_c     =  -1,

      delta_a = 0 ,
      gamma_a_z1 = 0 ,
      gamma_a_z2 = 0 ,
      gamma_a_z3 = 0 ,
      gamma_a_z4 = 0 ,
      gamma_a_z5 = 0 ,

      delta_b = 0 ,
      gamma_b_z1 = 0 ,
      gamma_b_z2 = 0 ,
      gamma_b_z3 = 0 ,
      gamma_b_z4 = 0 ,
      gamma_b_z5 = 0 ,

      delta_c = 0 ,
      gamma_c_z1 = 0 ,
      gamma_c_z2 = 0 ,
      gamma_c_z3 = 0 ,
      gamma_c_z4 = 0 ,
      gamma_c_z5 = 0

    )

  )

  # using MNL parameters for latent classes
  apollo_beta[grep("^x1_mu", names(apollo_beta))] <- init_values_for_classes["B_x1"]
  apollo_beta[grep("^x2_mu", names(apollo_beta))] <- init_values_for_classes["B_x2"]

  # set all variances at 0.1
  apollo_beta[grepl("sd", names(apollo_beta), fixed = TRUE)] <- 0.1


  # fixed parameters
  assign_for_apollo(
    name_apollo_object  = "apollo_fixed",
    value_object    = c(
      "delta_a",
      "gamma_a_z1" ,
      "gamma_a_z2" ,
      "gamma_a_z3" ,
      "gamma_a_z4" ,
      "gamma_a_z5" )
    )



  ### Set parameters for generating draws
  assign_for_apollo(
    name_apollo_object  = "apollo_draws",
    value_object   = list(
      interDrawsType= "halton",
      interNDraws   = N_draws,
      interUnifDraws= c(),
      interNormDraws=c("N_x1"   ,"N_x2"),

      intraDrawsType="mlhs",
      intraNDraws   =0,
      intraUnifDraws=c(),
      intraNormDraws=c()
    )
  )

  ### Create random parameters

  assign_for_apollo(
    name_apollo_object  = "apollo_randCoeff",
    value_object   = function(apollo_beta, apollo_inputs){
      randcoeff = list()

      randcoeff[["x1_a"]] = x1_mu_a  + x1_sd_a * N_x1
      randcoeff[["x1_b"]] = x1_mu_b  + x1_sd_b * N_x1
      randcoeff[["x1_c"]] = x1_mu_c  + x1_sd_c * N_x1

      randcoeff[["x2_a"]] = x2_mu_a  + x2_sd_a * N_x2
      randcoeff[["x2_b"]] = x2_mu_b  + x2_sd_b * N_x2
      randcoeff[["x2_c"]] = x2_mu_c  + x2_sd_c * N_x2


      return(randcoeff)
    }
  )



  ### LC component

  assign_for_apollo(
    name_apollo_object  = "apollo_lcPars",
    value_object = function(apollo_beta, apollo_inputs){
      lcpars = list()

      lcpars[["x1"]]    = list(x1_a,
                               x1_b,
                               x1_c)

      lcpars[["x2"]]    = list(x2_a,
                               x2_b,
                               x2_c)


      V=list()
      V[["class_a"]] = delta_a   +
        gamma_a_z1 * z1 +
        gamma_a_z2 * z2 +
        gamma_a_z3 * z3 +
        gamma_a_z4 * z4 +
        gamma_a_z5 * z5

      V[["class_b"]] =  delta_b   +
        gamma_b_z1 * z1 +
        gamma_b_z2 * z2 +
        gamma_b_z3 * z3 +
        gamma_b_z4 * z4 +
        gamma_b_z5 * z5

      V[["class_c"]] =  delta_c   +
        gamma_c_z1 * z1 +
        gamma_c_z2 * z2 +
        gamma_c_z3 * z3 +
        gamma_c_z4 * z4 +
        gamma_c_z5 * z5



      classAlloc_settings = list(
        classes      = c(class_a = 1,
                         class_b = 2,
                         class_c = 3),
        utilities    = V
      )

      lcpars[["pi_values"]] = apollo::apollo_classAlloc(classAlloc_settings)

      return(lcpars)
    }

  )


  # apollo validate inputs
  log <- utils::capture.output({
    apollo_inputs = apollo::apollo_validateInputs()
   })

  assign_for_apollo(name_apollo_object = "apollo_inputs",
                    value_object = apollo_inputs )

  assign_for_apollo(
    name_apollo_object  = "apollo_probabilities",
    value_object   = function(apollo_beta, apollo_inputs, functionality="estimate"){
      ### Attach inputs and detach after function exit
      apollo::apollo_attach(apollo_beta, apollo_inputs)
      on.exit(apollo::apollo_detach(apollo_beta, apollo_inputs))

      ### Create list of probabilities P
      P = list()

      ### Define settings for MNL model component that are generic across classes
      mnl_settings = list(
        alternatives = c(   alt1=1, alt2=2, alt3=3),
        avail        = list(alt1=1, alt2=1, alt3=1),
        choiceVar    = choice_wide
      )

      ### Loop over classes
      for(s in 1:3){
        ### Compute class-specific utilities
        V=list()

        V[["alt1"]]  =  x1[[s]]*x1_1 + x2[[s]]*x2_1
        V[["alt2"]]  =  x1[[s]]*x1_2 + x2[[s]]*x2_2
        V[["alt3"]]  =  x1[[s]]*x1_3 + x2[[s]]*x2_3

        mnl_settings$utilities = V
        mnl_settings$componentName = paste0("Class_",s)

        ### Compute within-class choice probabilities using MNL model
        P[[paste0("Class_",s)]] = apollo::apollo_mnl(mnl_settings, functionality)

        ### Take product across observation for same individual
        P[[paste0("Class_",s)]] = apollo::apollo_panelProd(P[[paste0("Class_",s)]], apollo_inputs ,functionality)

        ### Average across inter-individual draws within classes
        P[[paste0("Class_",s)]] = apollo::apollo_avgInterDraws(P[[paste0("Class_",s)]], apollo_inputs, functionality)
      }

      ### Compute latent class model probabilities
      lc_settings  = list(inClassProb = P,
                          classProb   = pi_values)
      P[["model"]] = apollo::apollo_lc(lc_settings, apollo_inputs, functionality)

      ### Prepare and return outputs of function
      P = apollo::apollo_prepareProb(P, apollo_inputs, functionality)
      return(P)
    }

  )


  # wrapper to get best N models out of the N candidates.
  res <- wrapper_to_get_best_N_models(nCandidates = nCandidates,
                                      N_best_models = N_best_models,
                                      apollo_beta = apollo_beta,
                                      apollo_fixed = apollo_fixed,
                                      apollo_probabilities = apollo_probabilities,
                                      apollo_inputs = apollo_inputs,
                                      max_iter_search_vals = max_iter_search_vals ,
                                      max_iter_final_models = max_iter_final_models)


  # Remove overload of apollo_objects in the .GlobalEnv
  clear_apollo_overflow()
  return(res)

}



