#' @importFrom partykit mob mob_control
#' @importFrom dfidx dfidx mob_control
#' @importFrom mlogit mlogit
#' @export

my_fit_for_MNL <- function(y,
                              x = NULL,
                              start = NULL,
                              weights = NULL,
                              offset  = NULL,
                              ...) {

  yx <- cbind(y,x)
  #First declare it as dfidx data
  d <- dfidx::dfidx(data = yx,
                    shape = "wide",
                    choice = "choice",
                    varying = 2:16, ## first if "y", then "x's" and finally "identifiers".
                    sep = ".",
                    idx = list(c("id_choice", "id")),  #obs= choice situation; id = individual
                    idnames = c(NA, "altern"))

  ## Create ASC
  d$alt_id <- d$idx$altern
  d$cte.sq <- as.numeric(d$idx$altern == 1)
  d$cte.a  <- as.numeric(d$idx$altern == 2)

  # declare formula for mlogit::mlogit()
  form_MOB<- as.formula(
    choice ~
      cte.sq    + cte.a +
      forest    + morbidity + land + cost + location  + 0 )

  # Fit MIXL using mlogit::mlogit()
  clogit_dfidx <- mlogit::mlogit(
    formula  = form_MOB ,
    data     = d,
    method   = 'bfgs',
    panel    = FALSE,
    reflevel = 1
  )
  # drop original data from mlogit object.
  return(clogit_dfidx)
}



mob_mnl <- function(database,
                    mob_alpha   = 0.05,
                    mob_minsize = 360){
  #-----------------------------------------#
  # Formula for partykit::mob()
  formula_mlogit_mob <- choice ~
    forest.1     + forest.2     + forest.3    +
    morbidity.1  + morbidity.2  + morbidity.3 +
    land.1       + land.2       + land.3      +
    location.1   + location.2   + location.3  +
    cost.1       + cost.2       + cost.3      +
    id_choice    +
    id + 0            |
    Seen_Energy       +
    Signed_Oath       +
    Gender            +
    Age               +
    Ethnicity         +
    NGO               +
    Electric_Bill     +
    Income            +
    Family            +
    Children          +
    Visit

  #Transform the data into factors if needed
  database <- transform(
    database ,
    ### Modification partition variable names
    Gender          = factor(gender          , ordered = FALSE ),
    Visit           = factor(nvisits         , levels = 0:1, labels = c("No", "Yes")),
    NGO             = factor(ngo             , levels = 0:1, labels = c("No", "Yes")) ,
    Children        = factor(children        , levels = 0:1, labels = c("No", "Yes")),
    Family          = factor(family          , levels = 0:1, labels = c("No", "Yes")),
    Ethnicity       = factor(ethnicity       , levels = 0:1, labels = c("No", "Yes")),
    Seen_Energy     = factor(seen_energy     , levels = 0:1, labels = c("No", "Yes")),
    Signed_Oath     = factor(signed_oath     , levels = 0:1, labels = c("No", "Yes")),
    Electric_Bill   = elec_bill  ,
    Age             = age        ,
    Income          = income
  )

  #------------------------------------------------------#
  #MOB-MIXL algorithm fitted at different number of draws

  start_time <- Sys.time()
  # Fit partykit::mob() using formula_mlogit_mob()
  fitted_tree <- partykit::mob(
    formula_mlogit_mob ,
    data         = database,
    fit          = my_fit_for_MNL,
    cluster      = id,
    na.action    = na.pass,
    control   = partykit::mob_control(ytype   = "data.frame",
                                      xtype   = "data.frame",
                                      minsize = mob_minsize,
                                      alpha   = mob_alpha,
                                      ordinal = "l2",
                                      nrep    = 10000)
  )
  end_time <- Sys.time()
  time_iter_MOB <- round(end_time - start_time, digits = 4)
  cat("\n","Time taken to estimate the MOB-MNL algorithm using ", time_iter_MOB,"\n" )
  #print tree on screen
  print(fitted_tree)

  return(fitted_tree)

}

