#' @export
assign_for_apollo <- function(
    name_apollo_object = "name_object",
    value_object = 0){

  assign(x        = name_apollo_object,
         value    = value_object,
         envir    = .GlobalEnv ,
         inherits = TRUE )

}
