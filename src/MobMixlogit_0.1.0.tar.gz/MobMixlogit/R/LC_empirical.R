#' @importFrom apollo apollo_validateInputs apollo_attach apollo_detach apollo_mnl apollo_panelProd apollo_prepareProb apollo_estimate
#' @importFrom utils capture.output
#' @importFrom stats setNames
#' @export


LC_empirical <- function(data_wide,
                         N_classes,
                         LC_MIXL = FALSE,
                         N_draws = 2,
                         N_cores = 1,
                         init_values_for_classes,
                         max_iter_search_vals  = 300,
                         max_iter_final_models = 800,
                         nCandidates = 3,
                         N_best_models  = 1,
                         outliers = 500,
                         alloc_model_is_cte_only = FALSE,
                         alloc_model_vars = NULL){
  # ----------------------------------- #
  ####      Previous Checks          ####
  # ----------------------------------- #

  if (!(N_classes == 3 | N_classes == 2)) {
    stop("Only LC model with 2 or 3 classes are allowed")
  }

  if (!is.logical(alloc_model_is_cte_only) ) {
    stop("Argument alloc_model_is_cte_only need to be logical")
  }

  # Model type identification.
  N_classes <- as.character(N_classes)
  alloc_model_is_cte_only <- as.character(alloc_model_is_cte_only)
  model_type <- paste0("N_classes_",N_classes,"_cte_only_",alloc_model_is_cte_only )

  # ----------------------------------- #
  ####      Model Building           ####
  # ----------------------------------- #

  # Remove overload of apollo_objects in the .GlobalEnv
  clear_apollo_overflow()

  # database object in .GlovEnv (unfortunately apollo requires that...)
  assign_for_apollo(
    name_apollo_object = "database",
    value_object = data_wide)

  # ----------------------------------- #
  ####         apollo_control        ####
  # ----------------------------------- #
  if (LC_MIXL == FALSE) {
    # Set core controls
    assign_for_apollo(
      name_apollo_object  = "apollo_control",
      value_object = list(
        modelName       = "LC_DeLaMaza_2021",
        modelDescr      = "LC",
        mixing          = FALSE,
        indivID         = "id",
        nCores          = N_cores
      )
    )
  }else if(LC_MIXL == TRUE){
    # Set core controls
    assign_for_apollo(
      name_apollo_object  = "apollo_control",
      value_object = list(
        modelName       = "LC_DeLaMaza_2021",
        modelDescr      = "LC",
        mixing          = TRUE,
        indivID         = "id",
        nCores          = N_cores
      )
    )
  }



  cat("\n","The LC models you will fit include:","\n" ,
      "* Latent Classes: ",N_classes,"\n",
      "* LC-MIXL?: ",LC_MIXL,"\n",
      "* Allocation model?: ",alloc_model_is_cte_only,"\n"
  )

  # ----------------------------------------- #
  ####         apollo_probabilities        ####
  # ----------------------------------------- #
  # "apollo_probabilities" depends on N_classes and "LC_MIXL"
  N_classes <- as.character(N_classes)
  LC_MIXL <- as.character(LC_MIXL)
  N_classes_and_LC_MIXL <- paste0("N_classes_",N_classes,"_LC_MIXL_",LC_MIXL )

  switch(N_classes_and_LC_MIXL ,
         "N_classes_2_LC_MIXL_TRUE" = {
           assign_for_apollo(name_apollo_object  = "apollo_probabilities",
                             value_object = .apollo_probabilities_LC_MIXL_2C)},

         "N_classes_2_LC_MIXL_FALSE" = {
           assign_for_apollo(name_apollo_object  = "apollo_probabilities",
                             value_object = .apollo_probabilities_LC_2C)},

         "N_classes_3_LC_MIXL_TRUE" = {

           assign_for_apollo(name_apollo_object  = "apollo_probabilities",
                             value_object = .apollo_probabilities_LC_MIXL_3C)},

         "N_classes_3_LC_MIXL_FALSE" = {
           assign_for_apollo(name_apollo_object  = "apollo_probabilities",
                             value_object = .apollo_probabilities_LC_3C)}
         )
  # ------------------------------------ #
  ####          apollo_fixed          ####
  # ------------------------------------ #
  # "apollo_fixed" only depends on the inclusion of socio-demographics vars in the allocation model
  if (alloc_model_is_cte_only == TRUE) {

    assign_for_apollo( name_apollo_object  = "apollo_fixed",
                       value_object = .apollo_fixed_LC_cte_only %>%
                         .modify_apollo_fixed(N_classes =  N_classes))


  } else if (alloc_model_is_cte_only == FALSE){

    assign_for_apollo(name_apollo_object  = "apollo_fixed",
                      value_object = .apollo_fixed_LC_cte_only %>%
                        .modify_apollo_fixed(alloc_model_vars = alloc_model_vars,
                                             N_classes =  N_classes))

  }

  # ------------------------------------ #
  ####          apollo_lcPars         ####
  # ------------------------------------ #
  # "apollo_lcPars" depends both on N_classes and if cte_only or not


  switch(model_type ,
         "N_classes_2_cte_only_TRUE" = {
           assign_for_apollo(name_apollo_object  = "apollo_lcPars",
                             value_object = .apollo_lcPars_2C_cte_only)},

         "N_classes_2_cte_only_FALSE" = {
           assign_for_apollo(
             name_apollo_object  = "apollo_lcPars",
                             value_object = .apollo_lcPars_2C_cte_only %>%
                               .modify_.apollo_lcPars(
                                 N_classes = N_classes,
                                 alloc_model_vars = alloc_model_vars)  )},

         "N_classes_3_cte_only_TRUE" = {

           assign_for_apollo(name_apollo_object  = "apollo_lcPars",
                             value_object = .apollo_lcPars_3C_cte_only)},

         "N_classes_3_cte_only_FALSE" = {
           assign_for_apollo(name_apollo_object  = "apollo_lcPars",
                             value_object = .apollo_lcPars_3C_cte_only%>%
                               .modify_.apollo_lcPars(
                                 N_classes = N_classes,
                                 alloc_model_vars = alloc_model_vars))}
         )

  # -------------------------------------- #
  ####          LC_MIXL == TRUE         ####
  # -------------------------------------- #
  # "apollo_beta" depends on:
  # LC_MIXL, N_classes and cte_only or not.
  if (LC_MIXL == TRUE) {
    # -------------------------------------- #
    ####          apollo_draws            ####
    # -------------------------------------- #
    assign_for_apollo(name_apollo_object  = "apollo_draws",
                      value_object = .apollo_draws_LC_MIXL(N_draws = N_draws ) )

    if (N_classes == 2) {
      assign_for_apollo(name_apollo_object  = "apollo_randCoeff",
                        value_object = .apollo_randCoeff_LC_MIXL_2C )

      } else if(N_classes == 3){
        assign_for_apollo(name_apollo_object  = "apollo_randCoeff",
                          value_object = .apollo_randCoeff_LC_MIXL_3C )
    }
    # ---------------------------------------- #
    #### apollo_beta when LC_MIXL == TRUE  ####
    # ---------------------------------------- #
    switch(model_type ,
           "N_classes_2_cte_only_TRUE" = {
             assign_for_apollo(name_apollo_object  = "apollo_beta",
                               value_object = .apollo_beta_LC_MIXL_2C_cte_only)},

           "N_classes_2_cte_only_FALSE" = {
             assign_for_apollo(name_apollo_object  = "apollo_beta",
                               value_object = .apollo_beta_LC_MIXL_2C_cte_only %>%
                                 .modify_apollo_beta(alloc_model_vars = alloc_model_vars,
                                                     N_classes = N_classes  )
                                 )},

           "N_classes_3_cte_only_TRUE" = {
             assign_for_apollo(name_apollo_object  = "apollo_beta",
                               value_object = .apollo_beta_LC_MIXL_3C_cte_only)},

           "N_classes_3_cte_only_FALSE" = {
             assign_for_apollo(name_apollo_object  = "apollo_beta",
                               value_object = .apollo_beta_LC_MIXL_3C_cte_only %>%
                                 .modify_apollo_beta(alloc_model_vars = alloc_model_vars,
                                                     N_classes = N_classes  )
                               )}
           )

    # -------------------------------------- #
    ####          LC_MIXL == FALSE        ####
    # -------------------------------------- #

    } else if(LC_MIXL == FALSE)  {



    switch(model_type ,
           # ---------------------------------------- #
           #### apollo_beta when LC_MIXL == FALSE  ####
           # ---------------------------------------- #
           "N_classes_2_cte_only_TRUE" = {
             assign_for_apollo(name_apollo_object  = "apollo_beta",
                               value_object = .apollo_beta_LC_2C_cte_only)},

           "N_classes_2_cte_only_FALSE" = {
             assign_for_apollo(name_apollo_object  = "apollo_beta",
                               value_object = .apollo_beta_LC_2C_cte_only %>%
                                 .modify_apollo_beta(N_classes = N_classes,
                                                     alloc_model_vars = alloc_model_vars) )},

           "N_classes_3_cte_only_TRUE" = {
             assign_for_apollo(name_apollo_object  = "apollo_beta",
                               value_object = .apollo_beta_LC_3C_cte_only)},

           "N_classes_3_cte_only_FALSE" = {
             assign_for_apollo(name_apollo_object  = "apollo_beta",
                               value_object = .apollo_beta_LC_3C_cte_only %>%
                                 .modify_apollo_beta(N_classes = N_classes,
                                                     alloc_model_vars = alloc_model_vars))}
           )

  }


  # using MNL parameters for latent classes
  apollo_beta[grep("^forest", names(apollo_beta))]             <- init_values_for_classes["forest"]
  apollo_beta[grep("^morbidity", names(apollo_beta))]          <- init_values_for_classes["morbidity"]
  apollo_beta[grep("^land", names(apollo_beta))]               <- init_values_for_classes["land"]
  apollo_beta[grepl("cost", names(apollo_beta), fixed = TRUE)] <- init_values_for_classes["cost"]

  apollo_beta[grep("^location_x_forest", names(apollo_beta))] <- init_values_for_classes["location_x_forest"]
  apollo_beta[grep("^asc1", names(apollo_beta))] <- init_values_for_classes["asc1"]
  apollo_beta[grep("^asc2", names(apollo_beta))] <- init_values_for_classes["asc1"]
  apollo_beta[grep("^asc3", names(apollo_beta))] <- init_values_for_classes["asc3"]

  # set all variances at 0.1
  apollo_beta[grepl("sd", names(apollo_beta), fixed = TRUE)] <- 0.1


  # -------------------------------------- #
  ####        apollo_validateInputs     ####
  # -------------------------------------- #
  log <- utils::capture.output({

    apollo_inputs = apollo::apollo_validateInputs()
  })

  assign_for_apollo(name_apollo_object = "apollo_inputs",
                    value_object = apollo_inputs )

  # wrapper to get best #N models out of the #N candidates.
  res <- wrapper_to_get_best_N_models(
    nCandidates = nCandidates,
    N_best_models = N_best_models,
    apollo_beta = apollo_beta,
    apollo_fixed = apollo_fixed,
    apollo_probabilities = apollo_probabilities,
    apollo_inputs = apollo_inputs,
    max_iter_search_vals  = max_iter_search_vals,
    max_iter_final_models = max_iter_final_models
  )

  # Remove overload of apollo_objects in the .GlobalEnv
  clear_apollo_overflow()

  return(res)

}
