#' @importFrom data.table dcast setDT
#' @importFrom magrittr "%>%"
#' @importFrom dplyr group_by mutate case_when
#' @export
long_to_wide<- function(long_data){

  #-----------------------------------------------------#
  # Preparing data:
  # 1) Create choice variable in Wide format.
  data <- long_data %>%
    dplyr::group_by(id) %>%
    dplyr::mutate(choice_wide = max(altern*choice_long)) %>%
    as.data.frame()

  # Reshape data from Long to Wide.
  df_wide <-   as.data.frame(
    data.table::dcast(
      data = data.table::as.data.table(data[c(
        "id",
        "id_ind",
        "id_choice",
        "altern",
        "x1", "x2",
        "choice_wide",
        "z1","z2","z3","z4","z5")]),
      formula =   id + id_ind + id_choice + choice_wide + z1 + z2 + z3 + z4 + z5 ~ altern  ,
      sep = "_" ,
      value.var=c("x1", "x2"),
      fun = mean
    )
  )
  return(df_wide)
}
