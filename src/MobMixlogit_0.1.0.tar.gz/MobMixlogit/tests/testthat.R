library(testthat)
library(MobMixlogit)

test_check("MobMixlogit")
