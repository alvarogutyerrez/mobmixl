test_that("mob-mnl() works", {

  # Loading the data
  database <- (function(...)get(data(...,envir = new.env(),package ="MobMixlogit")))("data_DeLaMaza_2021")
  #creating choice id
  database$id_choice <- 1:nrow(database)

  #-----------------------------------------#
  # MOB control parameters
  mob_alpha   <-  .00000005  #0.05
  mob_minsize <- 240


  fitted_tree <- mob_mnl(database    =  database,
                         mob_alpha   = mob_alpha,
                         mob_minsize = mob_minsize )

  expect_equal(object =   class(fitted_tree),
               expected = c("modelparty", "party"))
})
