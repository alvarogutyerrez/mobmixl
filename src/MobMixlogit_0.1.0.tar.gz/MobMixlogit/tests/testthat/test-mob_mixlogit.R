test_that("multiplication works", {

  # Loading the data
  database <- (function(...)get(data(...,envir = new.env(),package ="MobMixlogit")))("data_DeLaMaza_2021")
  #creating choice id
  database$id_choice <- 1:nrow(database)

  #-----------------------------------------#
  # MOB control parameters
  mob_alpha   <-  .000000001  #0.05
  mob_draws   <- c(2,3,4)     #c(1000,5000,10000)
  mob_minsize <- 240
  # Random parameters definition for mlogit::mlogit()
  mlogit_rpar<- c(forest            = "t",  # Triangular
                  morbidity         = "t",  # Triangular
                  cost              = "zbt" # Zero-bounded triangular
  )

  bag_of_models <- mob_mixlogit(database    =  database,
                                mob_alpha   = mob_alpha,
                                mob_draws   = mob_draws ,
                                mob_minsize = mob_minsize,
                                mlogit_rpar = mlogit_rpar )

  expect_equal(object =   class(bag_of_models[[1]]$MOB_MIXL),
               expected = c("modelparty", "party"))
})
