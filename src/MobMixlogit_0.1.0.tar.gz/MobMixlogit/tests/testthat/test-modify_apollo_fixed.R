test_that("modify_apollo_fixed works", {



  # two classes   + ctE_only
  .apollo_fixed_LC_modif_2C_cte_only  <- .modify_apollo_fixed(
    .apollo_fixed = .apollo_fixed_LC_cte_only,
    N_classes = 2)
  expect_equal(object = .apollo_fixed_LC_modif_2C_cte_only ,
               expected = c("asc3_a",
                            "asc3_b",
                            "delta_a"))

  # two classes   + socio
  .apollo_fixed_LC_modif_2C_socio  <- .modify_apollo_fixed(
    .apollo_fixed = .apollo_fixed_LC_cte_only,
    N_classes = 2,
    alloc_model_vars = c("income",
                         "nvisits" ,
                         "age" ,
                         "elec_bill" ,
                         "signed_oath"))

  expect_equal(object = .apollo_fixed_LC_modif_2C_socio ,
               expected = c("asc3_a",
                            "asc3_b",
                            "delta_a",
                            "gamma_a_income",
                            "gamma_a_nvisits",
                            "gamma_a_age",
                            "gamma_a_elec_bill",
                            "gamma_a_signed_oath"))

  # three classes  + cte_only
  .apollo_fixed_LC_modif_3C_cte_only  <- .modify_apollo_fixed(
    .apollo_fixed = .apollo_fixed_LC_cte_only,
    N_classes = 3)

  expect_equal(object = .apollo_fixed_LC_modif_3C_cte_only ,
               expected = c("asc3_a",
                            "asc3_b",
                            "delta_a",
                            "asc3_c" ))

  # three classes  + socio
  .apollo_fixed_LC_modif_3C_socio  <- .modify_apollo_fixed(
    .apollo_fixed = .apollo_fixed_LC_cte_only,
    N_classes = 3,
    alloc_model_vars = c("income",
                         "nvisits" ,
                         "age" ,
                         "elec_bill" ,
                         "signed_oath"))

  expect_equal(object = .apollo_fixed_LC_modif_3C_socio ,
               expected = c("asc3_a",
                            "asc3_b",
                            "delta_a",
                            "asc3_c",
                            "gamma_a_income",
                            "gamma_a_nvisits",
                            "gamma_a_age",
                            "gamma_a_elec_bill",
                            "gamma_a_signed_oath" ))





})
