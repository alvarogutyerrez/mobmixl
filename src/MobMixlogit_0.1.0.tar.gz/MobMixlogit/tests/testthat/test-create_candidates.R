test_that("create_candidates works", {

  library(apollo)

  #----------------------------------------------------------#
  # Test the creation of candidates for starting values

  initial_values <- list(B_x1= 1,B_x2=2,ASC = 0)

  # Apollo beta
  assign_for_apollo(
    name_apollo_object  = "apollo_beta",
    value_object = c(B_x1      =  initial_values$B_x1,
                     B_x2      =  initial_values$B_x2,
                     ASC_1       =  initial_values$ASC)
  )
  # Fixed parameters (just one)
  assign_for_apollo(
    name_apollo_object  = "apollo_fixed",
    value_object = c( "ASC_1"  )
  )

  candidates_test <- create_candidates(
    apollo_beta,
    apollo_fixed,
    nCandidates =10,
    seed = 123456L,
    apolloBetaMin = apollo_beta - 0.1,
    apolloBetaMax = apollo_beta + 0.1
    )

  #----------------------------------------------------------#
  # Test that the original initial values are actually there
  original_init_vals <- as.vector(candidates_test[[1]][2, ])

  expect_equal(object   = as.numeric(unlist(initial_values)),
               expected = original_init_vals)


  #----------------------------------------------------------#
  # Test that we include 0 as starting point.
  init_vals_at_zero <- as.vector(candidates_test[[1]][1, ])

  expect_equal(object   = rep(0,length(initial_values)),
               expected = init_vals_at_zero)

  #----------------------------------------------------------#
  # Test that we have different values for the third candidate
  rand_init_vals <- as.vector(candidates_test[[1]][3, ])

  expect_equal(object   = rand_init_vals ==as.numeric(unlist(initial_values)),
               # first two have to be different,
               # the third one has to be equal (because it is FIXED!)
               expected = c(FALSE,FALSE,TRUE) )

})
