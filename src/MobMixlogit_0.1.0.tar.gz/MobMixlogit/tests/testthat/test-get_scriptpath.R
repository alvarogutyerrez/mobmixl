test_that("get_scriptpath and get_scriptname works", {

  # get script path
  scriptpath  <- get_scriptpath()
  #get script name (from scriptpath)
  scriptname<- get_scriptname(scriptpath)
  #check that the name is correct.

  #expect_equal(scriptname, "test-get_scriptpath.R") # this only is testing in isolation.
  expect_equal(scriptname, "MobMixlogit")

})




