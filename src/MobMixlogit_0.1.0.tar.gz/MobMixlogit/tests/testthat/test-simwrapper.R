test_that("simwrapper works ", {

  #---------------------------------------------------------#
  # Test simwrapper in serial
  simwrapper_test <- simwrapper(
    n.indiv   =   c(50),
    n.choices =   c( 5 ) ,
    xi        =   c(0.5, 0.8 ) ,
    delta     =   c( 0.5, 1 ),
    nrep      =  1,
    scenario  = c("tree","stump"),
    draws     = 5 ,
    seed      = 0,
    run_in_parallel = FALSE)

  # Since it is a wrapper. Only test is the object is null.
  expect_equal(object = is.null(simwrapper_test),
               expected = FALSE)



  #---------------------------------------------------------#
  # Test simwrapper in parallel (2 cores)

  simwrapper_test <- simwrapper(
    n.indiv   =   c(50),
    n.choices =   c( 5 ) ,
    xi        =   c(0.5, 0.8 ) ,
    delta     =   c( 0.5, 1 ),
    nrep      =  1,
    scenario  = c("tree","stump"),
    draws     = 5 ,
    seed      = 0,
    run_in_parallel = TRUE,
    nClusters = 2)

  # Since it is a wrapper. Only test is the object is null.
  expect_equal(object = is.null(simwrapper_test),
               expected = FALSE)
})
