test_that("Generated data stump case", {

  #-----------------------------------------------#
  # True values of the dgp
  b1_mu <- 1
  b1_sd <- 0.001
  b2_mu <- 2
  b2_sd <- 0.001
  delta <- 1

  #-----------------------------------------------#
  # Data Generationg process Stump
  df <- dgp_stump(N = 500,
                  t = 20,
                  b1_mu = b1_mu,
                  b1_sd = b1_sd,
                  b2_mu = b2_mu,
                  b2_sd = b2_sd,
                  xi    = .5,
                  delta = delta)

  #-------------------------------------------------#
  # Test b1:
  # True mean (leave 2)
  expect_equal(object = mean(df[df$leaf==2,"beta1"]),
               expected = b1_mu,
               tolerance = 0.001)

  # True mean  (leave 3 + delta)
  expect_equal(object = mean(df[df$leaf==3,"beta1"]),
               expected = b1_mu + delta,
               tolerance = 0.001)

  #-------------------------------------------------#
  # Test b2
  # True mean (leave 2)
  expect_equal(object = mean(df[df$leaf==2,"beta2"]),
               expected = b2_mu,
               tolerance = 0.001)
  # True mean  (leave 3 + delta)
  expect_equal(object = mean(df[df$leaf==3,"beta2"]),
               expected = b2_mu + delta,
               tolerance = 0.001)


})
