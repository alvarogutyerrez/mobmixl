test_that("modify_apollo_lcPars", {



  .apollo_lcPars_2C_modified  <- .modify_.apollo_lcPars(
    .apollo_lcPars_to_modify = .apollo_lcPars_2C_cte_only,
    N_classes = 2,
    alloc_model_vars = c("age"))


    expect_equal(object = is.call(body(.apollo_lcPars_2C_modified)[[12]]),
                 expected = TRUE)


    .apollo_lcPars_3C_modified  <- .modify_.apollo_lcPars(
      .apollo_lcPars_to_modify = .apollo_lcPars_3C_cte_only,
      N_classes = 3,
      alloc_model_vars = c("age"))

    expect_equal(object = is.call(body(.apollo_lcPars_3C_modified)[[12]]),
                 expected = TRUE)



})
