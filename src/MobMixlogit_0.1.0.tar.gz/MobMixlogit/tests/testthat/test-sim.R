test_that("sim function works", {


  #---------------------------------------------#
  # DGP stump
  test_sim_stump <- sim(scenario = c("stump"),
                  n.indiv   = 100,
                  n.choices = 2 ,
                  n.alter   = 3,
                  nrep = 1,
                  seed = 0,
                  formula = y~x1+x2|z1+z2+z3+z4+z5,
                  xi = 0.5,
                  delta = 1,
                  draws = 20)

  # Create NaN in ari because it is not computed
  expect_equal(object =   test_sim_stump[[1]]$ari,
                 expected = NaN)

  #---------------------------------------------#
  # DGP tree
  test_sim_tree <- sim(scenario = c("tree"),
                  n.indiv   = 100,
                  n.choices = 2 ,
                  n.alter   = 3,
                  nrep = 1,
                  seed = 0,
                  formula = y~x1+x2|z1+z2+z3+z4+z5,
                  xi = 0.5,
                  delta = 1,
                  draws = 20)

  expect_equal(object =   is.numeric(test_sim_tree[[1]]$ari),
               expected = TRUE)


})
