test_that("LC_MIXL_3_sim works on LC-MIXL 3C data", {

  # Simulate data in long format
  data_long <- dgp_LC_3(N = 20,
                        t = 2,
                        J = 3)

  # transform it into wide format (for apollo)
  data_wide <- long_to_wide(data_long)

  #MNL estimates to be used as starting values
  mnl_estimates <- MNL_sim(data_wide)

  # LC model
  nCandidates <- 2
  N_best_models <- 1

  LC_3_model <- LC_MIXL_3_sim(
    data_wide = data_wide,
    nCandidates = nCandidates,
    N_best_models = N_best_models,
    N_cores = 1,
    init_values_for_classes = mnl_estimates,
    N_draws = 2,
    max_iter_search_vals = 2,
    max_iter_final_models = 1)

  expect_equal(object = class(LC_3_model$top_N_models[[1]]$final_model),
               expected =c("maxLik", "maxim" )  )
})


test_that("LC_MIXL_3_sim works on MOB-MIXL data", {

  # Simulate data in long format
  data_long <- dgp_tree(N = 20,
                        t = 2,
                        J = 3) %>%
    dplyr::rename(choice_long = chosen) %>%
    dplyr::rename(id_choice = id_choice_situation_of_individual_n)

  # transform it into wide format (for apollo)
  data_wide <- long_to_wide(data_long)

  #MNL estimates to be used as starting values
  mnl_estimates <- MNL_sim(data_wide)

  # LC model
  nCandidates <- 2
  N_best_models <- 1

  LC_3_model <- LC_MIXL_3_sim(
    data_wide = data_wide,
    nCandidates = nCandidates,
    N_best_models = N_best_models,
    N_cores = 1,
    init_values_for_classes = mnl_estimates,
    N_draws = 2,
    max_iter_search_vals = 2,
    max_iter_final_models = 1)

  expect_equal(object = class(LC_3_model$top_N_models[[1]]$final_model),
               expected =c("maxLik", "maxim" )  )
})


