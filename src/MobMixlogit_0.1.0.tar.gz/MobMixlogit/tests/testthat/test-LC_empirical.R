test_that("LC2 cte only works", {

  library(MobMixlogit)

  #Loading the data
  data_wide <- (function(...)get(data(...,envir = new.env(),
                                      package ="MobMixlogit")))("data_DeLaMaza_2021")
  #Starting values
  MNL_estimates <- MNL_empirical(data_wide = data_wide)

  #Number of candidates
  nCandidates <- 2

  N_best_models <- 1


  mo <- LC_empirical(
    data_wide = data_wide,
    init_values_for_classes = MNL_estimates,
    N_classes = 2,
    LC_MIXL = FALSE,
    alloc_model_is_cte_only = TRUE,
    max_iter_search_vals = 2,
    max_iter_final_models = 3,
    nCandidates = nCandidates
    )

  expect_equal(object   = length(mo$top_N_models[[1]]$final_model$estimate),
               expected = 18 )

  expect_equal(object = nrow(mo$fitted_possible_candidates),
               expected = nCandidates)

  expect_equal(object = length(mo$top_N_models),
               expected = N_best_models)


})


test_that("LC2 socio_demo works", {

  library(MobMixlogit)

  #Loading the data
  data_wide <- (function(...)get(data(...,envir = new.env(),
                                      package ="MobMixlogit")))("data_DeLaMaza_2021")
  #Starting values
  MNL_estimates <- MNL_empirical(data_wide = data_wide)

  #Number of candidates
  nCandidates <- 2

  N_best_models <- 1

  mo <- LC_empirical(
    data_wide = data_wide,
    init_values_for_classes = MNL_estimates,
    N_classes = 2,
    LC_MIXL = FALSE,
    alloc_model_is_cte_only = FALSE,
    max_iter_search_vals = 2,
    max_iter_final_models = 3,
    nCandidates = nCandidates,
    alloc_model_vars = c("income",
                         "nvisits" ,
                         "age" ,
                         "elec_bill" ,
                         "signed_oath")
  )

  expect_equal(object = nrow(mo$fitted_possible_candidates),
               expected = nCandidates)

  expect_equal(object = length(mo$top_N_models),
               expected = N_best_models)
})



test_that("LC3 cte only works", {

  library(MobMixlogit)

  #Loading the data
  data_wide <- (function(...)get(data(...,envir = new.env(),
                                      package ="MobMixlogit")))("data_DeLaMaza_2021")
  #Starting values
  MNL_estimates <- MNL_empirical(data_wide = data_wide)

  #Number of candidates
  nCandidates <- 2

  N_best_models <- 1


  mo <- LC_empirical(
    data_wide = data_wide,
    init_values_for_classes = MNL_estimates,
    N_classes = 3,
    LC_MIXL = FALSE,
    alloc_model_is_cte_only = TRUE,
    max_iter_search_vals = 2,
    max_iter_final_models = 3,
    nCandidates = nCandidates
  )

  expect_equal(object   = length(mo$top_N_models[[1]]$final_model$estimate),
               expected = 27 )

  expect_equal(object = nrow(mo$fitted_possible_candidates),
               expected = nCandidates)

  expect_equal(object = length(mo$top_N_models),
               expected = N_best_models)
})


test_that("LC3 socio_demo works", {

  library(MobMixlogit)

  #Loading the data
  data_wide <- (function(...)get(data(...,envir = new.env(),
                                      package ="MobMixlogit")))("data_DeLaMaza_2021")
  #Starting values
  MNL_estimates <- MNL_empirical(data_wide = data_wide)

  #Number of candidates
  nCandidates <- 2

  N_best_models <- 1


  mo <- LC_empirical(
    data_wide = data_wide,
    init_values_for_classes = MNL_estimates,
    N_classes = 3,
    LC_MIXL = FALSE,
    alloc_model_is_cte_only = FALSE,
    max_iter_search_vals = 2,
    max_iter_final_models = 3,
    nCandidates = nCandidates,
    alloc_model_vars = c("income",
                         "nvisits" ,
                         "age" ,
                         "elec_bill" ,
                         "signed_oath")
  )

  expect_equal(object = nrow(mo$fitted_possible_candidates),
               expected = nCandidates)

  expect_equal(object = length(mo$top_N_models),
               expected = N_best_models)
})



#### LC-MIXL ####

test_that("LC-MIXL 2C cte only works", {

  library(MobMixlogit)

  #Loading the data
  data_wide <- (function(...)get(data(...,envir = new.env(),
                                      package ="MobMixlogit")))("data_DeLaMaza_2021")
  #Starting values
  MNL_estimates <- MNL_empirical(data_wide = data_wide)

  #Number of candidates
  nCandidates <- 2

  N_best_models <- 1


  mo <- LC_empirical(
    data_wide = data_wide,
    init_values_for_classes = MNL_estimates,
    N_classes = 2,
    LC_MIXL = TRUE,
    N_draws = 2,
    alloc_model_is_cte_only = TRUE,
    max_iter_search_vals = 2,
    max_iter_final_models = 3,
    nCandidates = nCandidates
  )


  expect_equal(object = nrow(mo$fitted_possible_candidates),
               expected = nCandidates)

  expect_equal(object = length(mo$top_N_models),
               expected = N_best_models)


})



test_that("LC-MIXL 2C socio demo works", {

  library(MobMixlogit)

  #Loading the data
  data_wide <- (function(...)get(data(...,envir = new.env(),
                                      package ="MobMixlogit")))("data_DeLaMaza_2021")
  #Starting values
  MNL_estimates <- MNL_empirical(data_wide = data_wide)

  #Number of candidates
  nCandidates <- 2

  N_best_models <- 1


  mo <- LC_empirical(
    data_wide = data_wide,
    init_values_for_classes = MNL_estimates,
    N_classes = 2,
    LC_MIXL = TRUE,
    N_draws = 2,
    alloc_model_is_cte_only = FALSE,
    max_iter_search_vals = 2,
    max_iter_final_models = 3,
    nCandidates = nCandidates,
    alloc_model_vars = c("income",
                         "nvisits" ,
                         "age" ,
                         "elec_bill" ,
                         "signed_oath")
  )


  expect_equal(object = nrow(mo$fitted_possible_candidates),
               expected = nCandidates)

  expect_equal(object = length(mo$top_N_models),
               expected = N_best_models)


})



test_that("LC-MIXL 3C cte only works", {

  library(MobMixlogit)

  #Loading the data
  data_wide <- (function(...)get(data(...,envir = new.env(),
                                      package ="MobMixlogit")))("data_DeLaMaza_2021")
  #Starting values
  MNL_estimates <- MNL_empirical(data_wide = data_wide)

  #Number of candidates
  nCandidates <- 2

  N_best_models <- 1


  mo <- LC_empirical(
    data_wide = data_wide,
    init_values_for_classes = MNL_estimates,
    N_classes = 3,
    LC_MIXL = TRUE,
    N_draws = 2,
    alloc_model_is_cte_only = TRUE,
    max_iter_search_vals = 2,
    max_iter_final_models = 3,
    nCandidates = nCandidates
  )

  expect_equal(object   = length(mo$top_N_models[[1]]$final_model$estimate),
               expected = 33 )

  expect_equal(object = nrow(mo$fitted_possible_candidates),
               expected = nCandidates)

  expect_equal(object = length(mo$top_N_models),
               expected = N_best_models)


})




test_that("LC-MIXL 3C socio demo works", {

  library(MobMixlogit)

  #Loading the data
  data_wide <- (function(...)get(data(...,envir = new.env(),
                                      package ="MobMixlogit")))("data_DeLaMaza_2021")
  #Starting values
  MNL_estimates <- MNL_empirical(data_wide = data_wide)

  #Number of candidates
  nCandidates <- 2

  N_best_models <- 1

  mo <- LC_empirical(
    data_wide = data_wide,
    init_values_for_classes = MNL_estimates,
    N_classes = 3,
    LC_MIXL = TRUE,
    N_draws = 2,
    alloc_model_is_cte_only = FALSE,
    max_iter_search_vals = 2,
    max_iter_final_models = 3,
    nCandidates = nCandidates,
    alloc_model_vars = c("income",
                         "nvisits" ,
                         "age" ,
                         "elec_bill" ,
                         "signed_oath")
  )



  expect_equal(object = nrow(mo$fitted_possible_candidates),
               expected = nCandidates)

  expect_equal(object = length(mo$top_N_models),
               expected = N_best_models)


})


