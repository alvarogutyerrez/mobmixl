test_that("adj_rand_index works", {


  #-------------------------------------------------#
  # ARI (=1) (All predictions are correct)
  x <- c(1,1,1,2,2)
  y <- c(1,1,1,2,2)

  expect_equal(as.numeric(adj_rand_index(x,y)), 1)

  #-------------------------------------------------#
  # ARI (=0) (all predictions are wrong)
  x <- c(2,1,3)
  y <- c(1,2,2)

  expect_equal(as.numeric(adj_rand_index(x,y)), 0)


})
