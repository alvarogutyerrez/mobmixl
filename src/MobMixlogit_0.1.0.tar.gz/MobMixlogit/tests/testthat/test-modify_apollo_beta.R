test_that("modify_apollo_beta  works", {

  N_classes <- 3
  alloc_model_vars = c("income",
                       "nvisits" ,
                       "age" ,
                       "elec_bill" ,
                       "signed_oath")

  new_apollo_beta <- .modify_apollo_beta(apollo_beta_to_modify = .apollo_beta_LC_3C_cte_only ,
                                        N_classes = N_classes,
                                        alloc_model_vars = alloc_model_vars )


  expect_equal(object = length(new_apollo_beta),
               expected = length(.apollo_beta_LC_3C_cte_only) + N_classes * length(alloc_model_vars)  )




  N_classes <- 2

  new_apollo_beta <- .modify_apollo_beta(apollo_beta_to_modify = .apollo_beta_LC_2C_cte_only ,
                                        N_classes = N_classes,
                                        alloc_model_vars = alloc_model_vars )
  expect_equal(object = length(new_apollo_beta),
               expected = length(.apollo_beta_LC_2C_cte_only) + N_classes * length(alloc_model_vars)  )



})
