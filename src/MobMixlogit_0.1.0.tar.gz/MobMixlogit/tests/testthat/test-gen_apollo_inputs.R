test_that("gen_apollo_inputs works", {

  # Create objects n .GlobalEnv
  gen_apollo_inputs()

  # Check for their existence
  expect_equal( object =  exists("apollo_control", envir = .GlobalEnv, inherits = TRUE),
                 expected = TRUE)

  expect_equal( object =  exists("apollo_draws", envir = .GlobalEnv, inherits = TRUE),
                expected = TRUE)

  expect_equal( object =  exists("apollo_fixed", envir = .GlobalEnv, inherits = TRUE),
                expected = TRUE)

  expect_equal( object =  exists("apollo_lcPars", envir = .GlobalEnv, inherits = TRUE),
                expected = TRUE)

  expect_equal( object =  exists("apollo_randCoeff", envir = .GlobalEnv, inherits = TRUE),
                expected = TRUE)

})
