test_that("dgp_LC_3 is correctly generated", {

  #---------------------------------------------------------------------#
  # Check if parameters from the allocation model match the true values.
  library(nnet)
  N = 5000
  t = 2
  J = 3
  gamma_c1 = c(0,0,0,0,0)
  gamma_c2 = c(1,1,1,1,1)
  gamma_c3 = c(-1,-1,-1,-1,-1)
  ctes = c(0,1,-1)
  all_beta1 = c(-1,-2,-3)
  all_beta2 = c(3,2,1  )
  seed = 123456L

  # Generating the data.
  df <- dgp_LC_3(N = N,
                 t = t ,
                 J = J  ,
                 gamma_c1 = gamma_c1,
                 gamma_c2 = gamma_c2,
                 gamma_c3 = gamma_c3,
                 ctes = ctes,
                 all_beta1 = all_beta1,
                 all_beta2 = all_beta2,
                 seed = seed)

  # Recover parameters from the allocation model
  test <- nnet::multinom(formula = class~ 1 + z1 + z2 +  z3 + z4 + z5 ,
                   data = df)

  # Check if estimates are close enough to the true values
  expect_equal(object = c(ctes[2],gamma_c2) , # adding the cte.
               expected = as.numeric(coef(test)[1,]) ,
               tolerance = 0.1)

  # Check if estimates are close enough to the true values
  expect_equal(object = c(ctes[3],gamma_c3) , # adding the cte.
               expected = as.numeric(coef(test)[2,]) ,
               tolerance = 0.1)
  #---------------------------------------------------------------------#



})
