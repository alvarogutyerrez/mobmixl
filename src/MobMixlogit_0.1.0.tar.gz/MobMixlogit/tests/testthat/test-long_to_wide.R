test_that("long_to_wide works ", {

  library(dplyr)
  data_long <- dgp_tree(N = 1500,
                        t = 20,
                        J = 3,
                        delta = 1,
                        xi = 0.5 ) %>%
    dplyr::rename(choice_long = chosen) %>%
    dplyr::rename(id_choice = id_choice_situation_of_individual_n)

  # transform it into wide format (for apollo)
  data_wide <- long_to_wide(data_long)





  #  expect_equal(2 * 2, 4)
})
