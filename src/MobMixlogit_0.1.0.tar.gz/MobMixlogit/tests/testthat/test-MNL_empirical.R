test_that("multiplication works", {

  library(MobMixlogit)


  data_wide <- (function(...)get(data(...,envir = new.env(),
                                     package ="MobMixlogit")))("data_DeLaMaza_2021")

  MNL_estimates <- MNL_empirical(data_wide = data_wide)

  expect_equal(is.atomic(MNL_estimates),
               expected = TRUE
               )


  })
