test_that("fitting_MNL works", {

  library(apollo)

  data_long <- dgp_LC_3(N = 30,
                        t = 2,
                        J = 3)

  data_wide <- long_to_wide(data_long)

  mnl_estimates <- MNL_sim(data_wide = data_wide)

  expect_true(is.vector(mnl_estimates))

})
